/**
 * Incident probability defaults for Men's 200m (Wavesports AI).
 * Realistic rare defaults; all rates are per-athlete or per-attempt in [0, 1]
 * and overridable (or zeroed for a clean race) via `setup.incidentOverrides`.
 */

export interface IncidentConfigRates200m {
  /** Base probability per athlete of a false start (< 0.100s or pre-gun movement). */
  falseStartBaseRate: number;
  /** Base probability per athlete of a stumbled / slipped push-off from angled blocks. */
  stumbledStartRate: number;
  /** Base probability per athlete of a slip or fall on the bend (DNF). */
  fallOrTripRate: number;
  /** Base probability per athlete of a mid-race muscle pull injury (DNF). */
  injuryPullUpRate: number;
  /** Base probability per athlete of stepping on/inside inner lane line on bend (DQ). */
  laneViolationRate: number;
  /** Probability of an adjacent-lane brush/collision after a stumble or drift. */
  collisionBrushRate: number;
  /** Very rare call-room withdrawal after setup validation (DNS). */
  lateDnsRate: number;
  /** Very rare starting block slip requiring a recall & restart without penalty. */
  equipmentBlockSlipRate: number;
  /** Chance of a breakout performance / personal best run. */
  breakoutPerformanceRate: number;
  /** Maximum false-start / equipment recalls before forcing a clean start (capped at 3). */
  maxRecalls: number;
}

export const DEFAULT_INCIDENT_RATES_200M: IncidentConfigRates200m = {
  falseStartBaseRate: 0.025,
  stumbledStartRate: 0.028,
  fallOrTripRate: 0.012,
  injuryPullUpRate: 0.01,
  laneViolationRate: 0.014,
  collisionBrushRate: 0.006,
  lateDnsRate: 0.005,
  equipmentBlockSlipRate: 0.006,
  breakoutPerformanceRate: 0.04,
  maxRecalls: 3,
};

export function mergeIncidentRates200m(
  overrides?: Partial<IncidentConfigRates200m> | null
): IncidentConfigRates200m {
  if (!overrides) {
    return { ...DEFAULT_INCIDENT_RATES_200M };
  }
  const merged: IncidentConfigRates200m = { ...DEFAULT_INCIDENT_RATES_200M };
  (Object.keys(DEFAULT_INCIDENT_RATES_200M) as Array<keyof IncidentConfigRates200m>).forEach(
    (key) => {
      const val = overrides[key];
      if (typeof val === 'number' && Number.isFinite(val)) {
        merged[key] =
          key === 'maxRecalls'
            ? Math.max(0, Math.min(3, Math.round(val)))
            : Math.max(0, Math.min(1, val));
      }
    }
  );
  return merged;
}
