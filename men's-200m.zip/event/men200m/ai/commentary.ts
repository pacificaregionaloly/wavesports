import type {
  AthleteRaceResult200m,
  AthleteSetup200m,
  RaceIncidentRecord200m,
  RaceSetupPayload200m,
} from '../api/types';
import { SeededRNG200m } from './seededRng';

export interface CommentaryCue200m {
  atRaceTime: number;
  headline: string;
  line: string;
  phase: 'intro' | 'start' | 'recall' | 'live' | 'incident' | 'finish' | 'post';
}

export interface CommentaryContext200m {
  setup: RaceSetupPayload200m;
  windMps: number;
  windLegal: boolean;
  incidents: RaceIncidentRecord200m[];
  results: AthleteRaceResult200m[];
}

/**
 * Pluggable Commentary Generator interface so template generation can later
 * be swapped with an LLM-backed implementation.
 */
export interface CommentaryGenerator200m {
  generateLaneIntro(athlete: AthleteSetup200m, setup: RaceSetupPayload200m): string;
  generateStartPrompt(stage: 'on_your_marks' | 'set' | 'gun', attempt: number): string;
  generateIncidentCall(
    incident: RaceIncidentRecord200m,
    athlete: AthleteSetup200m | undefined
  ): string;
  generateRaceCues(
    ctx: CommentaryContext200m,
    snapshots: {
      leaderAt50?: AthleteSetup200m;
      leaderAtBendExit?: AthleteSetup200m;
      leaderAt150?: AthleteSetup200m;
      bendExitTimeSec: number;
    },
    rng: SeededRNG200m
  ): CommentaryCue200m[];
  generatePostRaceSummary(ctx: CommentaryContext200m): string;
}

export class TemplateCommentaryGenerator200m implements CommentaryGenerator200m {
  public generateLaneIntro(
    athlete: AthleteSetup200m,
    setup: RaceSetupPayload200m
  ): string {
    const pbStr = athlete.personalBest
      ? `PB ${athlete.personalBest.toFixed(2)}s`
      : 'Pacifica 200m contender';
    const sbStr = athlete.seasonBest
      ? ` · SB ${athlete.seasonBest.toFixed(2)}s`
      : '';
    return `Lane ${athlete.lane} (stagger): ${athlete.name} (${athlete.nationCode}) — ${pbStr}${sbStr} · ${setup.round.toUpperCase()} Heat ${setup.heat}`;
  }

  public generateStartPrompt(
    stage: 'on_your_marks' | 'set' | 'gun',
    attempt: number
  ): string {
    const restartTag = attempt > 0 ? ` (Restart #${attempt})` : '';
    if (stage === 'on_your_marks') {
      return `Sprinters settle into the angled blocks around the West Bend stagger${restartTag}.`;
    }
    if (stage === 'set') {
      return `Set… poised along the curve across all eight staggered lanes${restartTag}.`;
    }
    return `BANG! Clean break — the Men's 200 Metres explodes around the bend!`;
  }

  public generateIncidentCall(
    incident: RaceIncidentRecord200m,
    athlete: AthleteSetup200m | undefined
  ): string {
    const who = athlete
      ? `${athlete.shortName} (Lane ${athlete.lane}, ${athlete.nationCode})`
      : 'Track official alert';
    switch (incident.type) {
      case 'false_start':
        return `RECALL GUN! False start charged to ${who} (${incident.atTime.toFixed(
          3
        )}s) — red card shown!`;
      case 'equipment_issue':
        return `RECALL! Starting block slip on the bend in Lane ${
          incident.lane ?? '?'
        } — runners ordered back, no penalty.`;
      case 'stumbled_start':
        return `${who} slips leaving the angled blocks on the curve and fights to regain rhythm!`;
      case 'fall':
        return `DRAMA ON THE BEND! ${who} loses footing on the curve and slides out — DNF!`;
      case 'injury':
        return `${who} pulls up clutching the hamstring on the straight and slows to a stop (DNF).`;
      case 'lane_violation':
        return `Bend judges flag a lane-line infringement on ${who} — DQ under review.`;
      case 'collision':
        return `Tight shoulder brush between adjacent lanes involving ${who}!`;
      case 'late_dns':
        return `Late withdrawal in the call room: ${who} is scratched (DNS).`;
      case 'great_performance':
        return `ELECTRIC BEND & STRAIGHT! ${who} is flying off the curve!`;
    }
  }

  public generateRaceCues(
    ctx: CommentaryContext200m,
    snapshots: {
      leaderAt50?: AthleteSetup200m;
      leaderAtBendExit?: AthleteSetup200m;
      leaderAt150?: AthleteSetup200m;
      bendExitTimeSec: number;
    },
    rng: SeededRNG200m
  ): CommentaryCue200m[] {
    const cues: CommentaryCue200m[] = [];
    const finishers = ctx.results.filter((r) => r.status === 'finished');
    const winner = finishers[0];
    const runnerUp = finishers[1];

    cues.push({
      atRaceTime: 0.0,
      headline: 'AWAY THEY GO AROUND THE BEND!',
      line: rng.pick([
        "Clean start! Eight sprinters drive out of the staggered blocks in the Men's 200m!",
        'The gun cracks across Klemonserrat Stadium and the 200m bend battle is underway!',
        'Instant reaction around the curve — every runner chasing the stagger!',
      ]),
      phase: 'live',
    });

    if (snapshots.leaderAt50) {
      const a = snapshots.leaderAt50;
      cues.push({
        atRaceTime: 5.5,
        headline: 'LEADING ON THE STAGGER (50M)',
        line: `${a.name} (${a.nationCode}, Lane ${a.lane}) sets the early pace on the stagger midway through the bend!`,
        phase: 'live',
      });
    }

    if (snapshots.leaderAtBendExit) {
      const b = snapshots.leaderAtBendExit;
      cues.push({
        atRaceTime: Math.max(9.8, snapshots.bendExitTimeSec - 0.15),
        headline: 'ENTERING THE HOME STRAIGHT!',
        line: `${b.shortName} (${b.nationCode}) exits the bend first onto the 84.39 m home straight!`,
        phase: 'live',
      });
    }

    if (snapshots.leaderAt150) {
      const c = snapshots.leaderAt150;
      const leadChanged =
        snapshots.leaderAtBendExit &&
        snapshots.leaderAtBendExit.athleteId !== c.athleteId;
      cues.push({
        atRaceTime: 14.8,
        headline: leadChanged ? 'LEAD CHANGE ON THE STRAIGHT!' : 'FINAL 50M KICK!',
        line: leadChanged
          ? `${c.shortName} surges past off the bend to seize the lead entering the final 50 metres!`
          : `${c.shortName} holds command down the straight with 50 metres to the finish!`,
        phase: 'live',
      });
    }

    // Add live calls for in-race incidents
    ctx.incidents.forEach((inc) => {
      if (
        inc.type === 'stumbled_start' ||
        inc.type === 'fall' ||
        inc.type === 'injury' ||
        inc.type === 'collision' ||
        inc.type === 'lane_violation' ||
        inc.type === 'great_performance'
      ) {
        const ath = ctx.setup.athletes.find((a) => a.athleteId === inc.athleteId);
        cues.push({
          atRaceTime: Math.max(0.25, inc.atTime),
          headline: inc.type.replace(/_/g, ' ').toUpperCase(),
          line: this.generateIncidentCall(inc, ath),
          phase: 'incident',
        });
      }
    });

    if (winner) {
      const margin =
        runnerUp && winner.exactTime && runnerUp.exactTime
          ? runnerUp.exactTime - winner.exactTime
          : null;
      const winTime = (winner.time ?? 0).toFixed(2);
      const isPhoto = margin !== null && margin < 0.03;
      const windTag = `Wind ${ctx.windMps >= 0 ? '+' : ''}${ctx.windMps.toFixed(1)} m/s (${
        ctx.windLegal ? 'LEGAL' : 'WIND-AIDED'
      })`;

      cues.push({
        atRaceTime: Math.max(18.5, winner.time ?? 19.9),
        headline: isPhoto ? 'PHOTO FINISH AT THE LINE!' : `${winner.shortName} TAKES 200M GOLD!`,
        line:
          isPhoto && runnerUp
            ? `Photo finish! ${winner.name} (${winner.nationCode}) edges ${runnerUp.shortName} in ${winTime}s (${(
                margin! * 1000
              ).toFixed(0)} ms margin) · ${windTag}`
            : `${winner.name} (${winner.nationCode}) wins the Men's 200m in ${winTime}s! · ${windTag}`,
        phase: 'finish',
      });
    }

    cues.sort((a, b) => a.atRaceTime - b.atRaceTime);
    return cues;
  }

  public generatePostRaceSummary(ctx: CommentaryContext200m): string {
    const finishers = ctx.results.filter((r) => r.status === 'finished');
    const windStr = `${ctx.windMps >= 0 ? '+' : ''}${ctx.windMps.toFixed(1)} m/s (${
      ctx.windLegal ? 'legal' : 'wind-aided'
    })`;
    if (finishers.length === 0) {
      return `No finishers recorded in ${ctx.setup.raceId} (${windStr}).`;
    }
    const w = finishers[0];
    const second = finishers[1];
    const secondTxt = second
      ? `, ahead of ${second.shortName} (${second.nationCode}, ${second.time?.toFixed(2)}s)`
      : '';
    const incCount = ctx.incidents.length;
    const incTxt =
      incCount > 0 ? ` · ${incCount} official incident(s) logged.` : ' · Clean race.';
    return `${w.name} (${w.nationCode}) wins the Men's 200m in ${(w.time ?? 0).toFixed(
      2
    )}s${secondTxt} with ${windStr}${incTxt}`;
  }
}
