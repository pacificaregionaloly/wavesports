import React, { useState } from 'react';
import {
  AlertTriangle,
  Camera,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Eye,
  Film,
  Monitor,
  Play,
  RotateCcw,
  Ruler,
  ShieldCheck,
  Volume2,
  VolumeX,
  Wind,
} from 'lucide-react';
import { STADIUM_INTEGRITY_CALLS } from '../config';
import type { EventCameraId200m } from '../director/BroadcastDirector200m';
import type {
  Men200mRaceController,
  Men200mUIState,
} from '../sim/Men200mRaceController';

interface EventPanel200mProps {
  controller: Men200mRaceController;
  uiState: Men200mUIState;
  adminModeFromUrl: boolean;
}

const CAMERA_OPTIONS_200M: Array<{ id: EventCameraId200m; label: string }> = [
  { id: 'auto', label: 'Auto' },
  { id: 'staggerOverview', label: 'Stagger Overview' },
  { id: 'blocksHeadOn', label: 'Blocks' },
  { id: 'bendCam', label: 'Bend Cam' },
  { id: 'topDownOval', label: 'Top-Down Oval' },
  { id: 'trackingRail', label: 'Straight Rail' },
  { id: 'straightHeadOn', label: 'Straight Head-On' },
  { id: 'finishLine', label: 'Finish' },
  { id: 'photoFinish', label: 'Photo' },
  { id: 'replayCam', label: 'Replay' },
];

export const EventPanel200m: React.FC<EventPanel200mProps> = ({
  controller,
  uiState,
  adminModeFromUrl,
}) => {
  const [expanded, setExpanded] = useState(true);
  // Shown at startup per Stadium Integrity requirement, collapsible by user
  const [showIntegrity, setShowIntegrity] = useState(true);
  const [showStaggerDebug, setShowStaggerDebug] = useState(true);

  const isWaiting = uiState.raceState === 'WAITING_FOR_API';
  const isAdminVisible = adminModeFromUrl || uiState.allowManualStart || uiState.isMock;
  const canManualStart =
    uiState.staggerSelfCheck.passed &&
    uiState.allowManualStart &&
    uiState.raceState === 'READY';
  const canReplay =
    uiState.raceState === 'FINISHED' ||
    uiState.raceState === 'RESULTS_POSTED' ||
    uiState.isReplay;

  const stateColor =
    uiState.raceState === 'WAITING_FOR_API'
      ? uiState.apiConnectionState === 'error'
        ? 'bg-red-600 text-white'
        : 'bg-amber-500 text-slate-950'
      : uiState.raceState === 'FALSE_START_RECALL'
      ? 'bg-red-600 text-white'
      : uiState.raceState === 'RUNNING'
      ? 'bg-emerald-500 text-slate-950'
      : 'bg-[#0033a0] text-[#f5c542]';

  const apiStatusDot =
    uiState.apiConnectionState === 'connected'
      ? 'bg-emerald-400'
      : uiState.apiConnectionState === 'error'
      ? 'bg-red-500'
      : 'bg-amber-400';

  const windDisplay =
    uiState.windMps !== null
      ? `${uiState.windMps >= 0 ? '+' : ''}${uiState.windMps.toFixed(1)} m/s (${
          uiState.windLegal ? 'LEGAL' : 'AIDED'
        })`
      : 'Waiting…';

  const resultsById = new Map(
    (uiState.plan?.results ?? []).map((r) => [r.athleteId, r])
  );
  const athletesList = (uiState.setup?.athletes ?? [])
    .slice()
    .sort((a, b) => a.lane - b.lane);

  return (
    <>
      <aside
        aria-label="Wavesports AI Men's 200m Broadcast Panel"
        className="pointer-events-auto fixed left-3 sm:left-4 top-[104px] sm:top-[110px] z-20 w-[364px] max-w-[calc(100vw-24px)] rounded-xl border border-[#d4af37]/45 bg-[#041029]/95 text-white shadow-2xl"
      >
        {/* Header Bar */}
        <div className="flex items-center justify-between gap-2 border-b border-white/10 px-3 py-2">
          <div className="min-w-0">
            <div className="flex items-center gap-1.5">
              <span
                aria-hidden="true"
                className={`inline-block h-2 w-2 shrink-0 rounded-full ${apiStatusDot}`}
              />
              <h2 className="truncate font-display text-sm font-bold tracking-wide uppercase text-[#f5c542]">
                Wavesports AI – Men&apos;s 200m
              </h2>
            </div>
            {uiState.isMock && (
              <span className="mt-1 inline-block rounded bg-amber-400 px-1.5 py-0.5 font-mono text-[10px] font-extrabold text-slate-950">
                MOCK API – DEV ONLY
              </span>
            )}
          </div>

          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={() => controller.setMuted(!uiState.muted)}
              aria-label={uiState.muted ? 'Unmute Race Audio' : 'Mute Race Audio'}
              className="rounded p-1 text-slate-300 hover:bg-white/10 hover:text-white focus-visible:outline-2 focus-visible:outline-[#f5c542]"
            >
              {uiState.muted ? (
                <VolumeX className="h-3.5 w-3.5" />
              ) : (
                <Volume2 className="h-3.5 w-3.5" />
              )}
            </button>
            <button
              type="button"
              onClick={() => setExpanded((v) => !v)}
              aria-expanded={expanded}
              aria-label={expanded ? 'Collapse Men 200m Panel' : 'Expand Men 200m Panel'}
              className="rounded p-1 text-slate-300 hover:bg-white/10 hover:text-white focus-visible:outline-2 focus-visible:outline-[#f5c542]"
            >
              {expanded ? (
                <ChevronUp className="h-4 w-4" />
              ) : (
                <ChevronDown className="h-4 w-4" />
              )}
            </button>
          </div>
        </div>

        {/* Summary Strip */}
        <div className="flex flex-wrap items-center justify-between gap-2 px-3 py-1.5 text-[11px] bg-[#07183c]/80">
          <span className={`rounded px-1.5 py-0.5 font-mono font-bold ${stateColor}`}>
            {uiState.raceState}
          </span>
          <span className="font-mono text-base font-bold text-[#f5c542]">
            {uiState.raceClockSec.toFixed(2)}s
          </span>
          <span className="flex items-center gap-1 font-mono text-[10px] text-[#7dd3fc]">
            <Wind className="h-3 w-3" />
            {windDisplay}
          </span>
        </div>

        {/* Quick 200m Camera Buttons */}
        <div
          className="flex flex-wrap items-center gap-1.5 border-t border-white/10 bg-[#051434] px-3 py-1.5"
          role="group"
          aria-label="Men 200m Quick Cameras"
        >
          <button
            type="button"
            onClick={() => controller.selectCamera('staggerOverview')}
            aria-pressed={uiState.selectedCamera === 'staggerOverview'}
            className={`flex flex-1 items-center justify-center gap-1 rounded-md px-2 py-1 text-[10.5px] font-semibold whitespace-nowrap transition-colors focus-visible:outline-2 focus-visible:outline-[#f5c542] ${
              uiState.selectedCamera === 'staggerOverview'
                ? 'bg-[#0033a0] text-[#f5c542] ring-1 ring-[#f5c542]/70'
                : 'bg-[#07183c] text-slate-200 hover:bg-white/10 hover:text-white'
            }`}
          >
            <Eye className="h-3 w-3 shrink-0 text-[#f5c542]" />
            <span>Stagger View</span>
          </button>
          <button
            type="button"
            onClick={() => controller.selectCamera('bendCam')}
            aria-pressed={uiState.selectedCamera === 'bendCam'}
            className={`flex flex-1 items-center justify-center gap-1 rounded-md px-2 py-1 text-[10.5px] font-semibold whitespace-nowrap transition-colors focus-visible:outline-2 focus-visible:outline-[#f5c542] ${
              uiState.selectedCamera === 'bendCam'
                ? 'bg-[#0033a0] text-[#f5c542] ring-1 ring-[#f5c542]/70'
                : 'bg-[#07183c] text-slate-200 hover:bg-white/10 hover:text-white'
            }`}
          >
            <Camera className="h-3 w-3 shrink-0 text-[#7dd3fc]" />
            <span>Bend Cam</span>
          </button>
        </div>

        {expanded && (
          <div className="max-h-[calc(100vh-330px)] space-y-2.5 overflow-y-auto custom-scroll border-t border-white/10 p-3 text-xs">
            {/* API Connection & Race Metadata */}
            <div className="grid grid-cols-2 gap-1.5 rounded-lg border border-white/10 bg-[#07183c] p-2 text-[11px]">
              <div>
                <div className="text-[10px] uppercase text-slate-400">API State</div>
                <div className="font-semibold text-white">
                  {uiState.apiConnectionState === 'connected'
                    ? 'Connected'
                    : uiState.apiConnectionState === 'error'
                    ? 'Error / Retry'
                    : 'Waiting for Wavesports API…'}
                </div>
              </div>
              <div>
                <div className="text-[10px] uppercase text-slate-400">Race ID</div>
                <div className="truncate font-mono text-[#7dd3fc]">{uiState.raceId}</div>
              </div>
              <div>
                <div className="text-[10px] uppercase text-slate-400">Seed</div>
                <div className="font-mono text-[#f5c542]">
                  {uiState.seed !== null ? uiState.seed : '—'}
                </div>
              </div>
              <div>
                <div className="text-[10px] uppercase text-slate-400">Event</div>
                <div className="font-mono font-semibold text-slate-200">
                  men_200m
                </div>
              </div>
            </div>

            {/* Waiting / Error Alert */}
            {uiState.apiError && (
              <div
                role="alert"
                className="flex items-start gap-2 rounded-lg border border-red-400/50 bg-red-950/70 p-2 text-[11px] text-red-100"
              >
                <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-red-400" />
                <span>{uiState.apiError}</span>
              </div>
            )}

            {isWaiting && !uiState.apiError && (
              <div className="rounded-lg border border-[#d4af37]/35 bg-[#07183c] p-2.5 text-center text-[11px] text-slate-200">
                Waiting for Wavesports API… Stadium remains live &amp; orbitable.
                No athletes placed until validated 200m payload arrives.
              </div>
            )}

            {/* Staggered Start Self-Check Debug Panel */}
            <div className="rounded-lg border border-white/10 bg-[#07183c] p-2">
              <button
                type="button"
                onClick={() => setShowStaggerDebug((v) => !v)}
                aria-expanded={showStaggerDebug}
                className="flex w-full items-center justify-between text-[10px] font-bold uppercase tracking-wider text-slate-200"
              >
                <span className="flex items-center gap-1">
                  <Ruler className="h-3 w-3 text-[#f5c542]" />
                  Stagger Self-Check (200.00 ± 0.01 m)
                </span>
                <span
                  className={`flex items-center gap-1 rounded px-1.5 py-0.5 font-mono text-[9.5px] ${
                    uiState.staggerSelfCheck.passed
                      ? 'bg-emerald-500/20 text-emerald-300'
                      : 'bg-red-600 text-white'
                  }`}
                >
                  {uiState.staggerSelfCheck.passed ? (
                    <>
                      <CheckCircle2 className="h-2.5 w-2.5" /> PASS
                    </>
                  ) : (
                    'FAIL'
                  )}
                </span>
              </button>
              {showStaggerDebug && (
                <div className="mt-1.5 space-y-1">
                  <div className="flex justify-between font-mono text-[9.5px] text-slate-400">
                    <span>
                      Bend: {uiState.staggerSelfCheck.bendExitDistanceM.toFixed(2)}m
                    </span>
                    <span>
                      Straight: {uiState.staggerSelfCheck.homeStraightLengthM.toFixed(2)}m
                    </span>
                  </div>
                  <div className="grid grid-cols-4 gap-x-1 gap-y-0.5 border-t border-white/10 pt-1 font-mono text-[9.5px] text-slate-300">
                    <span className="text-slate-400">Lane</span>
                    <span className="text-right text-slate-400">Length</span>
                    <span className="text-right text-slate-400">Stagger</span>
                    <span className="text-right text-slate-400">Delta</span>
                    {uiState.staggerSelfCheck.lanes.map((l) => (
                      <React.Fragment key={l.lane}>
                        <span
                          className={
                            l.withinTolerance ? 'text-[#f5c542]' : 'text-red-400'
                          }
                        >
                          L{l.lane}
                        </span>
                        <span className="text-right">
                          {l.measuredLengthM.toFixed(2)}
                        </span>
                        <span className="text-right text-[#7dd3fc]">
                          +{l.staggerAheadOfLane1M.toFixed(2)}
                        </span>
                        <span className="text-right text-slate-400">
                          {l.lane === 1 ? '—' : `+${l.staggerDeltaFromPrevM.toFixed(2)}`}
                        </span>
                      </React.Fragment>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Stadium Integrity Panel (shown at startup) */}
            <div className="rounded-lg border border-emerald-500/30 bg-[#07183c] p-2">
              <button
                type="button"
                onClick={() => setShowIntegrity((v) => !v)}
                aria-expanded={showIntegrity}
                className="flex w-full items-center justify-between text-[10px] font-bold uppercase tracking-wider text-emerald-300"
              >
                <span className="flex items-center gap-1">
                  <ShieldCheck className="h-3.5 w-3.5 text-emerald-400" />
                  Stadium Integrity (Read-Only Verified)
                </span>
                <span className="text-slate-300">{showIntegrity ? 'Hide' : 'Show'}</span>
              </button>
              {showIntegrity && (
                <ul className="mt-1.5 space-y-0.5 font-mono text-[9.5px] text-slate-300">
                  <li className="text-emerald-300">
                    No stadium file or object was modified. Additions live in EventLayer_Men200m.
                  </li>
                  {STADIUM_INTEGRITY_CALLS.map((c) => (
                    <li key={c}>• {c}</li>
                  ))}
                </ul>
              )}
            </div>

            {/* Read-only Athletes List */}
            {athletesList.length > 0 && (
              <div>
                <div className="mb-1 flex items-center justify-between text-[10px] font-bold uppercase tracking-wider text-slate-300">
                  <span>Official 200m Field (Read-Only)</span>
                  <span>{athletesList.length} Lanes</span>
                </div>
                <ul className="space-y-1">
                  {athletesList.map((ath) => {
                    const res = resultsById.get(ath.athleteId);
                    const showOutcome =
                      uiState.raceState === 'FINISHED' ||
                      uiState.raceState === 'RESULTS_POSTED';
                    return (
                      <li
                        key={ath.athleteId}
                        className="flex items-center justify-between rounded bg-[#07183c] px-2 py-1 text-[11px]"
                      >
                        <div className="flex min-w-0 items-center gap-1.5">
                          <span
                            className="inline-block h-3 w-1.5 rounded-sm"
                            style={{ backgroundColor: ath.kit.primary }}
                          />
                          <span className="font-mono font-bold text-[#f5c542]">
                            L{ath.lane}
                          </span>
                          <span className="truncate font-semibold text-white">
                            {ath.shortName}
                          </span>
                          <span className="text-[10px] text-slate-400">
                            {ath.nationCode}
                          </span>
                        </div>
                        <span className="shrink-0 font-mono text-[10px] text-[#7dd3fc]">
                          {showOutcome && res
                            ? res.status === 'finished'
                              ? `${res.rank}. ${res.time?.toFixed(2)}s`
                              : res.status
                            : ath.status === 'dns'
                            ? 'DNS'
                            : ath.personalBest
                            ? `PB ${ath.personalBest.toFixed(2)}`
                            : `#${ath.bib}`}
                        </span>
                      </li>
                    );
                  })}
                </ul>
              </div>
            )}

            {/* Live Incident Log */}
            <div>
              <div className="mb-1 text-[10px] font-bold uppercase tracking-wider text-slate-300">
                Incident Log ({uiState.visibleIncidents.length})
              </div>
              {uiState.visibleIncidents.length === 0 ? (
                <div className="rounded bg-[#07183c]/60 px-2 py-1.5 text-[11px] text-slate-400">
                  No incidents reported.
                </div>
              ) : (
                <ul className="space-y-1">
                  {uiState.visibleIncidents.map((inc, i) => (
                    <li
                      key={`${inc.code}-${inc.attempt}-${i}`}
                      className="rounded border border-amber-400/30 bg-amber-950/35 px-2 py-1 text-[11px] text-amber-100"
                    >
                      <span className="font-mono text-[10px] font-bold text-[#f5c542]">
                        [{inc.code}]
                      </span>{' '}
                      {inc.detail}
                    </li>
                  ))}
                </ul>
              )}
            </div>

            {/* 200m Camera Selector */}
            <div className="space-y-1.5 rounded-lg border border-white/10 bg-[#07183c] p-2">
              <div className="flex items-center justify-between text-[10px] font-bold uppercase tracking-wider text-slate-300">
                <span className="flex items-center gap-1">
                  <Camera className="h-3 w-3 text-[#f5c542]" />
                  200m Cameras
                </span>
                {uiState.directorUserOverride && (
                  <span className="text-[10px] text-sky-300">Orbit Override</span>
                )}
              </div>
              <div
                className="flex flex-wrap gap-1"
                role="group"
                aria-label="Men 200m Camera Angles"
              >
                {CAMERA_OPTIONS_200M.map((cam) => {
                  const active = uiState.selectedCamera === cam.id;
                  return (
                    <button
                      key={cam.id}
                      type="button"
                      onClick={() => controller.selectCamera(cam.id)}
                      aria-pressed={active}
                      className={`rounded px-2 py-0.5 text-[10px] font-semibold focus-visible:outline-2 focus-visible:outline-[#f5c542] ${
                        active
                          ? 'bg-[#0033a0] text-[#f5c542] ring-1 ring-[#f5c542]/50'
                          : 'bg-[#041029] text-slate-300 hover:bg-white/10 hover:text-white'
                      }`}
                    >
                      {cam.label}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Race & Admin Controls (disabled while WAITING_FOR_API unless dev mock) */}
            {isAdminVisible && (
              <div className="space-y-2 rounded-lg border border-[#d4af37]/40 bg-[#07183c] p-2.5">
                <div className="flex items-center justify-between text-[10px] font-bold uppercase tracking-wider text-[#f5c542]">
                  <span>Broadcast Controls</span>
                  {isWaiting && (
                    <span className="text-[9.5px] text-slate-400">
                      Locked until API setup
                    </span>
                  )}
                </div>

                {uiState.allowManualStart && (
                  <button
                    type="button"
                    disabled={!canManualStart}
                    onClick={() => controller.triggerManualStart()}
                    aria-label="Manual Admin Start Race"
                    className={`flex w-full items-center justify-center gap-1.5 rounded-md px-2.5 py-1.5 text-xs font-bold focus-visible:outline-2 focus-visible:outline-[#f5c542] ${
                      canManualStart
                        ? 'bg-[#d4af37] text-[#041029] hover:bg-[#f5c542]'
                        : 'cursor-not-allowed bg-slate-800 text-slate-500'
                    }`}
                  >
                    <Play className="h-3.5 w-3.5" />
                    <span>Manual Start (API Override)</span>
                  </button>
                )}

                <div className="flex gap-1.5">
                  <button
                    type="button"
                    disabled={isWaiting}
                    onClick={() =>
                      controller.setDirectorEnabled(!uiState.directorEnabled)
                    }
                    aria-pressed={uiState.directorEnabled}
                    className={`flex flex-1 items-center justify-center gap-1 rounded px-2 py-1 text-[11px] font-semibold focus-visible:outline-2 focus-visible:outline-[#f5c542] disabled:cursor-not-allowed disabled:opacity-45 ${
                      uiState.directorEnabled && !uiState.directorUserOverride
                        ? 'bg-[#0033a0] text-[#f5c542] ring-1 ring-[#f5c542]/50'
                        : 'bg-[#041029] text-slate-300 hover:bg-white/10'
                    }`}
                  >
                    <Camera className="h-3 w-3" />
                    <span>Director {uiState.directorEnabled ? 'ON' : 'OFF'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => controller.resetView()}
                    className="flex items-center gap-1 rounded bg-[#041029] px-2 py-1 text-[11px] font-semibold text-slate-200 hover:bg-white/10 focus-visible:outline-2 focus-visible:outline-[#f5c542]"
                  >
                    <RotateCcw className="h-3 w-3" />
                    <span>Reset View</span>
                  </button>
                </div>

                <div className="flex flex-wrap gap-1.5 border-t border-white/10 pt-1.5">
                  <button
                    type="button"
                    disabled={!canReplay}
                    onClick={() => controller.startReplay(1)}
                    className={`flex flex-1 items-center justify-center gap-1 rounded px-2 py-1 text-[11px] font-semibold ${
                      canReplay
                        ? 'bg-[#041029] text-white hover:bg-[#0033a0]'
                        : 'cursor-not-allowed bg-slate-900 text-slate-600'
                    }`}
                  >
                    <Film className="h-3 w-3" />
                    <span>Replay 1x</span>
                  </button>
                  <button
                    type="button"
                    disabled={!canReplay}
                    onClick={() => controller.startReplay(0.25)}
                    className={`flex flex-1 items-center justify-center gap-1 rounded px-2 py-1 text-[11px] font-semibold ${
                      canReplay
                        ? 'bg-[#041029] text-[#f5c542] hover:bg-[#0033a0]'
                        : 'cursor-not-allowed bg-slate-900 text-slate-600'
                    }`}
                  >
                    <Eye className="h-3 w-3" />
                    <span>0.25x Slow</span>
                  </button>
                  {uiState.isReplay && (
                    <button
                      type="button"
                      onClick={() => controller.stopReplay()}
                      className="rounded bg-red-700 px-2 py-1 text-[11px] font-semibold text-white hover:bg-red-600"
                    >
                      Stop
                    </button>
                  )}
                </div>

                <button
                  type="button"
                  disabled={isWaiting}
                  onClick={() => controller.setLiveMiniView(!uiState.liveMiniView)}
                  aria-pressed={uiState.liveMiniView}
                  className={`flex w-full items-center justify-center gap-1.5 rounded px-2 py-1 text-[10px] font-semibold disabled:cursor-not-allowed disabled:opacity-45 ${
                    uiState.liveMiniView
                      ? 'bg-[#0033a0] text-[#f5c542]'
                      : 'bg-[#041029] text-slate-300 hover:bg-white/10'
                  }`}
                >
                  <Monitor className="h-3 w-3" />
                  <span>
                    West Board Top-Down Oval: {uiState.liveMiniView ? 'ON' : 'OFF'}
                  </span>
                </button>

                {uiState.isMock && (
                  <div className="flex flex-wrap gap-1 border-t border-white/10 pt-1.5">
                    <button
                      type="button"
                      disabled={uiState.raceState !== 'READY'}
                      onClick={() => controller.devMockTrigger('start')}
                      className="flex-1 rounded bg-emerald-700 px-2 py-1 text-[10px] font-bold text-white disabled:opacity-40"
                    >
                      Mock: Start Cmd
                    </button>
                    <button
                      type="button"
                      onClick={() => controller.devMockTrigger('reset')}
                      className="rounded bg-slate-700 px-2 py-1 text-[10px] font-bold text-white"
                    >
                      Reset
                    </button>
                    <button
                      type="button"
                      onClick={() => controller.devMockTrigger('new_seed')}
                      className="rounded bg-slate-700 px-2 py-1 text-[10px] font-bold text-white"
                    >
                      New Seed
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </aside>

      {/* WSTV Broadcast Lower-Third Commentary Bar */}
      {uiState.setup && (
        <div
          aria-live="polite"
          className="pointer-events-none fixed bottom-[164px] lg:bottom-[116px] left-1/2 z-10 w-[680px] max-w-[calc(100vw-24px)] -translate-x-1/2 rounded-lg border border-[#d4af37]/50 bg-[#041029]/95 px-3.5 py-2 shadow-2xl"
        >
          <div className="flex items-center justify-between gap-2 text-[10px] font-bold tracking-wider uppercase text-[#f5c542]">
            <span>WSTV COMMENTARY · {uiState.latestHeadline}</span>
            {uiState.isReplay && (
              <span className="rounded bg-red-600 px-1.5 py-0.5 text-white">
                REPLAY {uiState.replaySpeed}x
              </span>
            )}
          </div>
          <p className="mt-0.5 text-xs font-medium text-white">
            {uiState.latestCaption}
          </p>
        </div>
      )}
    </>
  );
};
