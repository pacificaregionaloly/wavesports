import type { PersonInstance } from '../../../src/people/PersonFactory';
import type { AthletePoseAction200m } from '../ai/WavesportsAI200m';

/**
 * Applies expressive articulated Men's 200m race animations onto a stadium `PersonInstance`
 * inside EventLayer_Men200m without modifying `PersonFactory.ts` or `PeopleManager.ts`.
 * Includes authentic inward curve lean (`bendLeanRad`) around the West Bend.
 */
export function applyAthletePose200m(
  p: PersonInstance,
  pose: AthletePoseAction200m,
  elapsedSec: number,
  speedMps: number,
  stridePhase: number,
  bendLeanRad = 0
): void {
  const t = elapsedSec + p.phase;
  p.bodyPivot.position.set(0, 0, 0);
  p.bodyPivot.rotation.set(0, 0, 0);

  switch (pose) {
    case 'still': {
      p.torso.rotation.set(0.02, 0, 0);
      p.leftShoulder.rotation.set(0, 0, -0.06);
      p.rightShoulder.rotation.set(0, 0, 0.06);
      p.leftElbow.rotation.x = -0.18;
      p.rightElbow.rotation.x = -0.18;
      p.leftHip.rotation.x = 0;
      p.rightHip.rotation.x = 0;
      p.leftKnee.rotation.x = 0;
      p.rightKnee.rotation.x = 0;
      break;
    }

    case 'walkout': {
      const cycle = t * 5.4;
      const s = Math.sin(cycle);
      p.bodyPivot.position.y = Math.abs(Math.cos(cycle)) * 0.03;
      p.torso.rotation.set(0.04, s * 0.05, 0);
      p.leftHip.rotation.x = s * 0.42;
      p.rightHip.rotation.x = -s * 0.42;
      p.leftKnee.rotation.x = Math.max(0.05, -Math.cos(cycle) * 0.45 + 0.25);
      p.rightKnee.rotation.x = Math.max(0.05, Math.cos(cycle) * 0.45 + 0.25);
      p.leftShoulder.rotation.set(-s * 0.35, 0, -0.08);
      p.rightShoulder.rotation.set(s * 0.35, 0, 0.08);
      p.leftElbow.rotation.x = -0.35;
      p.rightElbow.rotation.x = -0.35;
      break;
    }

    case 'stretch_shakeout': {
      const mode = Math.floor((t * 0.45) % 2);
      if (mode === 0) {
        // High-knee shakeout skips
        const c = t * 6.0;
        const l = Math.max(0, Math.sin(c));
        const r = Math.max(0, -Math.sin(c));
        p.bodyPivot.position.y = Math.abs(Math.cos(c)) * 0.04;
        p.torso.rotation.set(0.06, 0, 0);
        p.leftHip.rotation.x = -l * 0.85;
        p.rightHip.rotation.x = -r * 0.85;
        p.leftKnee.rotation.x = l * 1.15;
        p.rightKnee.rotation.x = r * 1.15;
        p.leftShoulder.rotation.set(Math.sin(c) * 0.45, 0, -0.12);
        p.rightShoulder.rotation.set(-Math.sin(c) * 0.45, 0, 0.12);
        p.leftElbow.rotation.x = -1.1;
        p.rightElbow.rotation.x = -1.1;
      } else {
        // Arm swing & calf bounce
        const b = Math.abs(Math.sin(t * 4.5)) * 0.03;
        p.bodyPivot.position.y = b;
        p.torso.rotation.set(0.08, Math.sin(t * 2.0) * 0.08, 0);
        p.leftShoulder.rotation.set(Math.sin(t * 4.2) * 0.55, 0, -0.15);
        p.rightShoulder.rotation.set(-Math.sin(t * 4.2) * 0.55, 0, 0.15);
        p.leftElbow.rotation.x = -0.3;
        p.rightElbow.rotation.x = -0.3;
        p.leftHip.rotation.x = -0.05;
        p.rightHip.rotation.x = 0.05;
        p.leftKnee.rotation.x = 0.1;
        p.rightKnee.rotation.x = 0.1;
      }
      break;
    }

    case 'on_your_marks': {
      // Deep kneeling crouch in the angled blocks
      p.bodyPivot.position.set(0, -0.46, -0.18);
      p.torso.rotation.set(1.12, 0, 0);
      p.leftShoulder.rotation.set(-1.35, 0, -0.12);
      p.rightShoulder.rotation.set(-1.35, 0, 0.12);
      p.leftElbow.rotation.x = -0.1;
      p.rightElbow.rotation.x = -0.1;
      p.leftHip.rotation.x = -1.18;
      p.rightHip.rotation.x = -0.68;
      p.leftKnee.rotation.x = 1.65;
      p.rightKnee.rotation.x = 1.38;
      break;
    }

    case 'set_crouch': {
      // Hips raised, coiled tension ready to explode around the bend
      const microBreath = Math.sin(t * 2.8) * 0.006;
      p.bodyPivot.position.set(0, -0.27 + microBreath, -0.1);
      p.torso.rotation.set(1.38, 0, 0);
      p.leftShoulder.rotation.set(-1.45, 0, -0.1);
      p.rightShoulder.rotation.set(-1.45, 0, 0.1);
      p.leftElbow.rotation.x = -0.08;
      p.rightElbow.rotation.x = -0.08;
      p.leftHip.rotation.x = -1.05;
      p.rightHip.rotation.x = -0.58;
      p.leftKnee.rotation.x = 1.05;
      p.rightKnee.rotation.x = 0.78;
      break;
    }

    case 'false_start_twitch': {
      const j = Math.sin(t * 14) * 0.12;
      p.bodyPivot.position.set(0, -0.08, 0.25);
      p.torso.rotation.set(0.42 + j, 0.12, 0);
      p.leftShoulder.rotation.set(-0.9, 0, -0.2);
      p.rightShoulder.rotation.set(0.5, 0, 0.2);
      p.leftElbow.rotation.x = -1.1;
      p.rightElbow.rotation.x = -1.1;
      p.leftHip.rotation.x = -0.65;
      p.rightHip.rotation.x = 0.35;
      p.leftKnee.rotation.x = 0.85;
      p.rightKnee.rotation.x = 0.3;
      break;
    }

    case 'sprint': {
      const s = Math.sin(stridePhase);
      const c = Math.cos(stridePhase);
      const driveBlend = Math.max(0, Math.min(1, (speedMps - 2) / 9.5));
      const torsoLean = 0.56 - driveBlend * 0.34;
      const amp = 0.72 + driveBlend * 0.42;

      p.bodyPivot.position.y = Math.abs(c) * (0.06 + driveBlend * 0.05);
      // Negative rotation around local +Z tilts runner inward (+X) into left-hand bend
      p.bodyPivot.rotation.z = -bendLeanRad;
      p.torso.rotation.set(torsoLean, s * 0.08, 0);

      p.leftHip.rotation.x = s * amp;
      p.rightHip.rotation.x = -s * amp;
      p.leftKnee.rotation.x = Math.max(0.08, -c * 1.15 + 0.55);
      p.rightKnee.rotation.x = Math.max(0.08, c * 1.15 + 0.55);

      p.leftShoulder.rotation.set(-s * (0.95 + driveBlend * 0.3), 0, -0.12);
      p.rightShoulder.rotation.set(s * (0.95 + driveBlend * 0.3), 0, 0.12);
      p.leftElbow.rotation.x = -1.55;
      p.rightElbow.rotation.x = -1.55;
      break;
    }

    case 'stumble': {
      const wobble = Math.sin(stridePhase * 1.3);
      p.bodyPivot.position.y = -0.06 + Math.abs(wobble) * 0.04;
      p.bodyPivot.rotation.z = wobble * 0.16 - bendLeanRad * 0.5;
      p.torso.rotation.set(0.68, wobble * 0.22, wobble * 0.14);
      p.leftShoulder.rotation.set(-0.9 + wobble * 0.6, 0, -0.45);
      p.rightShoulder.rotation.set(-0.6 - wobble * 0.6, 0, 0.45);
      p.leftElbow.rotation.x = -0.8;
      p.rightElbow.rotation.x = -0.8;
      p.leftHip.rotation.x = wobble * 0.75;
      p.rightHip.rotation.x = -wobble * 0.65;
      p.leftKnee.rotation.x = 0.9;
      p.rightKnee.rotation.x = 0.6;
      break;
    }

    case 'fall_slide': {
      p.bodyPivot.position.set(0, -0.78, 0.15);
      p.bodyPivot.rotation.set(1.42, 0.18, 0.28);
      p.torso.rotation.set(0.2, 0, 0);
      p.leftShoulder.rotation.set(-1.2, 0, -0.45);
      p.rightShoulder.rotation.set(-0.9, 0, 0.5);
      p.leftElbow.rotation.x = -0.7;
      p.rightElbow.rotation.x = -0.9;
      p.leftHip.rotation.x = -0.35;
      p.rightHip.rotation.x = 0.25;
      p.leftKnee.rotation.x = 0.65;
      p.rightKnee.rotation.x = 0.3;
      break;
    }

    case 'pull_up_injured': {
      const hop = Math.abs(Math.sin(stridePhase * 0.8)) * 0.04;
      p.bodyPivot.position.y = hop;
      p.torso.rotation.set(0.28, -0.18, 0.1);
      p.leftShoulder.rotation.set(0.35, 0, -0.15);
      p.rightShoulder.rotation.set(-0.4, 0, 0.25);
      p.leftElbow.rotation.x = -1.25;
      p.rightElbow.rotation.x = -0.6;
      p.leftHip.rotation.x = -0.25;
      p.rightHip.rotation.x = 0.35;
      p.leftKnee.rotation.x = 0.45;
      p.rightKnee.rotation.x = 0.15;
      break;
    }

    case 'limp': {
      const l = Math.sin(t * 3.2);
      p.bodyPivot.position.y = -0.05 + Math.max(0, l) * 0.03;
      p.bodyPivot.rotation.z = l * 0.08;
      p.torso.rotation.set(0.25, -0.08, 0.06);
      p.leftShoulder.rotation.set(0.2, 0, -0.12);
      p.rightShoulder.rotation.set(-0.35, 0, 0.2);
      p.leftElbow.rotation.x = -0.9;
      p.rightElbow.rotation.x = -0.5;
      p.leftHip.rotation.x = -0.15;
      p.rightHip.rotation.x = l * 0.25;
      p.leftKnee.rotation.x = 0.35;
      p.rightKnee.rotation.x = 0.12;
      break;
    }

    case 'lean_finish': {
      const s = Math.sin(stridePhase);
      p.bodyPivot.position.y = 0.04;
      p.bodyPivot.rotation.z = -bendLeanRad * 0.4;
      p.torso.rotation.set(0.68, 0, 0);
      p.leftShoulder.rotation.set(0.95, 0, -0.22);
      p.rightShoulder.rotation.set(0.95, 0, 0.22);
      p.leftElbow.rotation.x = -0.35;
      p.rightElbow.rotation.x = -0.35;
      p.leftHip.rotation.x = s * 0.85;
      p.rightHip.rotation.x = -s * 0.85;
      p.leftKnee.rotation.x = 0.55;
      p.rightKnee.rotation.x = 0.55;
      break;
    }

    case 'celebrate': {
      const jump = Math.abs(Math.sin(t * 4.2)) * 0.08;
      p.bodyPivot.position.y = jump;
      p.torso.rotation.set(-0.08, Math.sin(t * 2.2) * 0.18, 0);
      p.leftShoulder.rotation.set(-2.65, 0, -0.25);
      p.rightShoulder.rotation.set(-2.65 + Math.sin(t * 6) * 0.2, 0, 0.25);
      p.leftElbow.rotation.x = -0.35;
      p.rightElbow.rotation.x = -0.35;
      p.leftHip.rotation.x = Math.sin(t * 4.2) * 0.22;
      p.rightHip.rotation.x = -Math.sin(t * 4.2) * 0.22;
      p.leftKnee.rotation.x = 0.2;
      p.rightKnee.rotation.x = 0.2;
      break;
    }

    case 'disappointed': {
      p.bodyPivot.position.y = -0.05;
      p.torso.rotation.set(0.32, Math.sin(t * 1.4) * 0.08, 0);
      p.leftShoulder.rotation.set(-0.42, 0, -0.14);
      p.rightShoulder.rotation.set(-0.42, 0, 0.14);
      p.leftElbow.rotation.x = -0.45;
      p.rightElbow.rotation.x = -0.45;
      p.leftHip.rotation.x = -0.22;
      p.rightHip.rotation.x = -0.22;
      p.leftKnee.rotation.x = 0.35;
      p.rightKnee.rotation.x = 0.35;
      break;
    }
  }
}
