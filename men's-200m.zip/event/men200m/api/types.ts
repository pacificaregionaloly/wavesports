import type { IncidentConfigRates200m } from '../config/incidents';

export type RaceState200m =
  | 'WAITING_FOR_API'
  | 'SETUP_RECEIVED'
  | 'VALIDATED'
  | 'ATHLETES_ON_TRACK'
  | 'READY'
  | 'ON_YOUR_MARKS'
  | 'SET'
  | 'RUNNING'
  | 'FALSE_START_RECALL'
  | 'FINISHED'
  | 'RESULTS_POSTED';

export interface AthleteKit200m {
  primary: string;
  secondary: string;
  accent: string;
}

export interface AthleteRatings200m {
  reaction: number;
  acceleration: number;
  topSpeed: number;
  speedEndurance: number;
  consistency: number;
  composure: number;
  durability: number;
  technique: number;
}

export type AthleteInitialStatus200m = 'active' | 'dns';

export interface AthleteSetup200m {
  athleteId: string;
  lane: number;
  name: string;
  shortName: string;
  nation: string;
  nationCode: string;
  bib: string;
  kit: AthleteKit200m;
  ratings: AthleteRatings200m;
  personalBest?: number;
  seasonBest?: number;
  status: AthleteInitialStatus200m;
}

export interface RaceRules200m {
  falseStartDisqualifies: boolean;
  windLimitMps: number;
}

export interface RaceSetupPayload200m {
  raceId: string;
  event: 'men_200m';
  round: string;
  heat: number;
  seed: number;
  scheduledStartTime?: string | null;
  allowManualStart: boolean;
  venue: string;
  rules: RaceRules200m;
  incidentOverrides?: Partial<IncidentConfigRates200m> | null;
  athletes: AthleteSetup200m[];
}

export type RaceCommand200m =
  | { command: 'start'; issuedAt: string }
  | { command: 'abort'; reason?: string }
  | { command: 'reset' };

export interface RaceStatusUpdate200m {
  status: string;
  athleteId?: string;
  detail?: string;
  timestamp?: string;
}

export type IncidentType200m =
  | 'false_start'
  | 'stumbled_start'
  | 'fall'
  | 'injury'
  | 'lane_violation'
  | 'collision'
  | 'late_dns'
  | 'equipment_issue'
  | 'great_performance';

export interface RaceIncidentRecord200m {
  type: IncidentType200m;
  code: string;
  athleteId: string | null;
  lane: number | null;
  attempt: number;
  atTime: number;
  detail: string;
}

export type AthleteResultStatus200m = 'finished' | 'DQ' | 'DNF' | 'DNS';

export interface AthleteRaceResult200m {
  rank: number | null;
  lane: number;
  athleteId: string;
  name: string;
  shortName: string;
  nation: string;
  nationCode: string;
  bib: string;
  time?: number;
  exactTime?: number;
  reactionTime?: number;
  splits?: {
    '50': number;
    '100': number;
    '150': number;
  };
  bendTime?: number;
  straightTime?: number;
  topSpeedMps?: number;
  status: AthleteResultStatus200m;
  reason?: string;
  notes: string[];
}

export interface RaceResultsPayload200m {
  raceId: string;
  seed: number;
  completedAt: string;
  wind: {
    mps: number;
    legal: boolean;
  };
  incidents: RaceIncidentRecord200m[];
  results: AthleteRaceResult200m[];
}
