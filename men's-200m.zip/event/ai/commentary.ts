import type {
  AthleteRaceResult,
  AthleteSetup,
  RaceIncidentRecord,
  RaceSetupPayload,
} from '../api/types';
import { SeededRNG } from './seededRng';

export interface CommentaryCue {
  /** Time relative to final race gun in seconds (negative = pre-gun / call room). */
  atRaceTime: number;
  headline: string;
  line: string;
  phase: 'intro' | 'start' | 'recall' | 'live' | 'incident' | 'finish' | 'post';
}

export interface CommentaryContext {
  setup: RaceSetupPayload;
  windMps: number;
  windLegal: boolean;
  incidents: RaceIncidentRecord[];
  results: AthleteRaceResult[];
}

/**
 * Pluggable Commentary Generator interface so template generation can later
 * be swapped with an LLM-backed implementation.
 */
export interface CommentaryGenerator {
  generateLaneIntro(athlete: AthleteSetup, setup: RaceSetupPayload): string;
  generateStartPrompt(stage: 'on_your_marks' | 'set' | 'gun', attempt: number): string;
  generateIncidentCall(
    incident: RaceIncidentRecord,
    athlete: AthleteSetup | undefined
  ): string;
  generateRaceCues(
    ctx: CommentaryContext,
    leaderAt40: AthleteSetup | undefined,
    leaderAt75: AthleteSetup | undefined,
    rng: SeededRNG
  ): CommentaryCue[];
  generatePostRaceSummary(ctx: CommentaryContext): string;
}

export class TemplateCommentaryGenerator implements CommentaryGenerator {
  public generateLaneIntro(athlete: AthleteSetup, setup: RaceSetupPayload): string {
    const pbStr = athlete.personalBest
      ? `PB ${athlete.personalBest.toFixed(2)}s`
      : 'Pacifica contender';
    const sbStr = athlete.seasonBest
      ? ` · SB ${athlete.seasonBest.toFixed(2)}s`
      : '';
    return `Lane ${athlete.lane}: ${athlete.name} (${athlete.nationCode}) — ${pbStr}${sbStr} · ${setup.round.toUpperCase()} Heat ${setup.heat}`;
  }

  public generateStartPrompt(
    stage: 'on_your_marks' | 'set' | 'gun',
    attempt: number
  ): string {
    const restartTag = attempt > 0 ? ` (Restart #${attempt})` : '';
    if (stage === 'on_your_marks') {
      return `Runners step into the blocks${restartTag}. Quiet in Klemonserrat Stadium.`;
    }
    if (stage === 'set') {
      return `Set… tension builds along all eight lanes${restartTag}.`;
    }
    return `BANG! Clean break — the Men's 100 Metres is underway!`;
  }

  public generateIncidentCall(
    incident: RaceIncidentRecord,
    athlete: AthleteSetup | undefined
  ): string {
    const who = athlete
      ? `${athlete.shortName} (Lane ${athlete.lane}, ${athlete.nationCode})`
      : 'Track official alert';
    switch (incident.type) {
      case 'false_start':
        return `RECALL GUN! False start charged to ${who} (${incident.atTime.toFixed(3)}s) — red card shown!`;
      case 'equipment_issue':
        return `RECALL! Starting block slip in Lane ${incident.lane ?? '?'} — runners ordered back, no penalty.`;
      case 'stumbled_start':
        return `${who} slips slightly pushing out of the blocks and fights for balance!`;
      case 'fall':
        return `DRAMA ON THE TRACK! ${who} loses footing and goes down hard — DNF!`;
      case 'injury':
        return `${who} pulls up clutching the hamstring mid-race and slows to a stop.`;
      case 'lane_violation':
        return `Stewards flag a lane-line infringement on ${who}.`;
      case 'collision':
        return `Tight brush between adjacent lanes involving ${who}!`;
      case 'late_dns':
        return `Late withdrawal in the call room: ${who} is scratched (DNS).`;
      case 'great_performance':
        return `ELECTRIC FORM! ${who} is flying down the home straight!`;
    }
  }

  public generateRaceCues(
    ctx: CommentaryContext,
    leaderAt40: AthleteSetup | undefined,
    leaderAt75: AthleteSetup | undefined,
    rng: SeededRNG
  ): CommentaryCue[] {
    const cues: CommentaryCue[] = [];
    const finishers = ctx.results.filter((r) => r.status === 'finished');
    const winner = finishers[0];
    const runnerUp = finishers[1];

    cues.push({
      atRaceTime: 0.0,
      headline: 'AWAY THEY GO!',
      line: rng.pick([
        "Clean start! Eight sprinters explode out of the blocks in the Men's 100m!",
        'The gun cracks across Klemonserrat Stadium and the 100m charge is on!',
        'Instant reaction off the line — the Pacifica 100m sprint is underway!',
      ]),
      phase: 'live',
    });

    if (leaderAt40) {
      cues.push({
        atRaceTime: 4.5,
        headline: 'DRIVE PHASE COMPLETE (40M)',
        line: `${leaderAt40.name} (${leaderAt40.nationCode}) leads through 40 metres into upright sprinting!`,
        phase: 'live',
      });
    }

    if (leaderAt75) {
      cues.push({
        atRaceTime: 7.4,
        headline: 'TOP-END SPEED (75M)',
        line:
          leaderAt40 && leaderAt40.athleteId !== leaderAt75.athleteId
            ? `${leaderAt75.shortName} surges past into the lead approaching the final 20 metres!`
            : `${leaderAt75.shortName} is in full command with 25 metres to the line!`,
        phase: 'live',
      });
    }

    // Add live calls for in-race incidents
    ctx.incidents.forEach((inc) => {
      if (
        inc.type === 'stumbled_start' ||
        inc.type === 'fall' ||
        inc.type === 'injury' ||
        inc.type === 'collision' ||
        inc.type === 'great_performance'
      ) {
        const ath = ctx.setup.athletes.find((a) => a.athleteId === inc.athleteId);
        cues.push({
          atRaceTime: Math.max(0.2, inc.atTime),
          headline: inc.type.replace(/_/g, ' ').toUpperCase(),
          line: this.generateIncidentCall(inc, ath),
          phase: 'incident',
        });
      }
    });

    if (winner) {
      const margin =
        runnerUp && winner.exactTime && runnerUp.exactTime
          ? runnerUp.exactTime - winner.exactTime
          : null;
      const winTime = (winner.time ?? 0).toFixed(2);
      const isPhoto = margin !== null && margin < 0.03;
      const windTag = `Wind ${ctx.windMps >= 0 ? '+' : ''}${ctx.windMps.toFixed(1)} m/s (${
        ctx.windLegal ? 'LEGAL' : 'WIND-AIDED'
      })`;

      cues.push({
        atRaceTime: Math.max(9.5, winner.time ?? 9.9),
        headline: isPhoto ? 'PHOTO FINISH AT THE LINE!' : `${winner.shortName} TAKES GOLD!`,
        line: isPhoto && runnerUp
          ? `Photo finish! ${winner.name} (${winner.nationCode}) edges ${runnerUp.shortName} in ${winTime}s (${(margin! * 1000).toFixed(0)} ms margin) · ${windTag}`
          : `${winner.name} (${winner.nationCode}) wins the Men's 100m in ${winTime}s! · ${windTag}`,
        phase: 'finish',
      });
    }

    cues.sort((a, b) => a.atRaceTime - b.atRaceTime);
    return cues;
  }

  public generatePostRaceSummary(ctx: CommentaryContext): string {
    const finishers = ctx.results.filter((r) => r.status === 'finished');
    const windStr = `${ctx.windMps >= 0 ? '+' : ''}${ctx.windMps.toFixed(1)} m/s (${
      ctx.windLegal ? 'legal' : 'wind-aided'
    })`;
    if (finishers.length === 0) {
      return `No finishers recorded in ${ctx.setup.raceId} (${windStr}).`;
    }
    const w = finishers[0];
    const second = finishers[1];
    const secondTxt = second
      ? `, ahead of ${second.shortName} (${second.nationCode}, ${second.time?.toFixed(2)}s)`
      : '';
    const incCount = ctx.incidents.length;
    const incTxt =
      incCount > 0 ? ` · ${incCount} official incident(s) logged.` : ' · Clean race.';
    return `${w.name} (${w.nationCode}) wins in ${(w.time ?? 0).toFixed(2)}s${secondTxt} with ${windStr}${incTxt}`;
  }
}
