import type {
  AthleteRaceResult,
  AthleteSetup,
  RaceIncidentRecord,
  RaceResultsPayload,
  RaceSetupPayload,
} from '../api/types';
import { mergeIncidentRates } from '../config/incidents';
import {
  type CommentaryCue,
  type CommentaryGenerator,
  TemplateCommentaryGenerator,
} from './commentary';
import { SeededRNG } from './seededRng';

export type AthletePoseAction =
  | 'still'
  | 'walkout'
  | 'stretch_shakeout'
  | 'on_your_marks'
  | 'set_crouch'
  | 'false_start_twitch'
  | 'sprint'
  | 'stumble'
  | 'fall_slide'
  | 'pull_up_injured'
  | 'limp'
  | 'lean_finish'
  | 'celebrate'
  | 'disappointed';

export interface AthleteFrameSample {
  distanceM: number;
  speedMps: number;
  lateralOffsetM: number;
  pose: AthletePoseAction;
}

export interface PlannedAttempt {
  attemptIndex: number;
  holdDurationSec: number;
  activeAthleteIds: string[];
  recalled: boolean;
  recallReason?: 'false_start' | 'equipment_issue';
  recallAtTimeSec?: number;
  offendingAthleteId?: string;
  incidents: RaceIncidentRecord[];
}

export interface PlannedAthleteRun {
  athlete: AthleteSetup;
  initialDns: boolean;
  lateDns: boolean;
  dqOnAttempt?: number;
  reactionTimeSec: number;
  topSpeedMps: number;
  splits: { '20': number; '40': number; '60': number; '80': number };
  exactFinishTimeSec: number | null;
  displayFinishTimeSec: number | null;
  status: 'finished' | 'DQ' | 'DNF' | 'DNS';
  reason?: string;
  notes: string[];
  /** Samples at fixed 1/30 s intervals starting at t = 0 (gun) through t = totalSimDurationSec. */
  frames: AthleteFrameSample[];
}

export interface RacePlan {
  setup: RaceSetupPayload;
  seed: number;
  windMps: number;
  windLegal: boolean;
  attempts: PlannedAttempt[];
  finalAttemptIndex: number;
  totalSimDurationSec: number;
  athleteRuns: Map<string, PlannedAthleteRun>;
  incidents: RaceIncidentRecord[];
  results: AthleteRaceResult[];
  resultsPayload: RaceResultsPayload;
  laneIntros: Map<string, string>;
  commentaryCues: CommentaryCue[];
  postRaceSummary: string;
}

const FIXED_HZ = 30;
const FIXED_DT = 1 / FIXED_HZ;
const SUBSTEPS = 10;
const SUB_DT = FIXED_DT / SUBSTEPS;

function clamp(v: number, lo: number, hi: number): number {
  return Math.max(lo, Math.min(hi, v));
}

function roundTo(v: number, decimals: number): number {
  const f = Math.pow(10, decimals);
  return Math.round(v * f) / f;
}

export class WavesportsAI {
  private readonly commentary: CommentaryGenerator;

  constructor(commentaryGenerator: CommentaryGenerator = new TemplateCommentaryGenerator()) {
    this.commentary = commentaryGenerator;
  }

  public plan(setup: RaceSetupPayload): RacePlan {
    const rng = new SeededRNG(setup.seed);
    const rates = mergeIncidentRates(setup.incidentOverrides);

    // 1. Seeded wind in [-1.5, +3.0] m/s
    const rawWind = rng.range(-1.5, 3.0);
    const windMps = roundTo(rawWind, 1);
    const windLegal = windMps <= setup.rules.windLimitMps;

    const allIncidents: RaceIncidentRecord[] = [];
    const attempts: PlannedAttempt[] = [];
    const dqMap = new Map<string, { attempt: number; reason: string }>();
    const lateDnsSet = new Set<string>();

    // Lane introductions
    const laneIntros = new Map<string, string>();
    setup.athletes.forEach((a) => {
      laneIntros.set(a.athleteId, this.commentary.generateLaneIntro(a, setup));
    });

    // 2. Evaluate initial DNS & rare call-room late DNS
    const eligibleAthletes: AthleteSetup[] = [];
    setup.athletes
      .slice()
      .sort((a, b) => a.lane - b.lane)
      .forEach((ath) => {
        if (ath.status === 'dns') {
          return;
        }
        if (rng.next() < rates.lateDnsRate && eligibleAthletes.length >= 2) {
          lateDnsSet.add(ath.athleteId);
          allIncidents.push({
            type: 'late_dns',
            code: 'LATE_DNS_CALL_ROOM',
            athleteId: ath.athleteId,
            lane: ath.lane,
            attempt: 0,
            atTime: -18.0,
            detail: `${ath.name} withdrew in the call room prior to track walkout.`,
          });
          return;
        }
        eligibleAthletes.push(ath);
      });

    // Guarantee at least 2 runners if late DNS thinned too aggressively
    let activeRoster = [...eligibleAthletes];
    if (activeRoster.length === 0) {
      activeRoster = setup.athletes.filter((a) => a.status === 'active');
    }

    // 3. Simulate start attempts (false starts + equipment block slips up to maxRecalls)
    let attemptIdx = 0;
    while (attemptIdx <= rates.maxRecalls) {
      const holdDurationSec = roundTo(rng.range(1.5, 2.5), 2);
      const canRecall = attemptIdx < rates.maxRecalls && activeRoster.length > 2;
      const attemptIncidents: RaceIncidentRecord[] = [];

      // Check rare starting block equipment slip
      if (canRecall && rng.next() < rates.equipmentBlockSlipRate * activeRoster.length) {
        const affected = rng.pick(activeRoster);
        const slipTime = roundTo(rng.range(0.05, 0.25), 3);
        const inc: RaceIncidentRecord = {
          type: 'equipment_issue',
          code: 'BLOCK_SLIP_RECALL',
          athleteId: affected.athleteId,
          lane: affected.lane,
          attempt: attemptIdx,
          atTime: slipTime,
          detail: `Starting block pad slipped in Lane ${affected.lane} (${affected.shortName}); recall fired.`,
        };
        attemptIncidents.push(inc);
        allIncidents.push(inc);
        attempts.push({
          attemptIndex: attemptIdx,
          holdDurationSec,
          activeAthleteIds: activeRoster.map((a) => a.athleteId),
          recalled: true,
          recallReason: 'equipment_issue',
          recallAtTimeSec: slipTime,
          offendingAthleteId: affected.athleteId,
          incidents: attemptIncidents,
        });
        attemptIdx++;
        continue;
      }

      // Check per-athlete false start probability
      let falseStarter: { ath: AthleteSetup; atTime: number } | null = null;
      if (canRecall) {
        for (const ath of activeRoster) {
          // Higher composure lowers false start risk; super-aggressive reaction raises it slightly
          const composureFactor = 1.45 - (ath.ratings.composure / 100) * 0.9;
          const eagernessFactor = 0.8 + (ath.ratings.reaction / 100) * 0.4;
          const pFalse = clamp(
            rates.falseStartBaseRate * composureFactor * eagernessFactor,
            0,
            0.35
          );
          if (rng.next() < pFalse) {
            const atTime = roundTo(rng.range(-0.14, 0.085), 3);
            if (!falseStarter || atTime < falseStarter.atTime) {
              falseStarter = { ath, atTime };
            }
          }
        }
      }

      if (falseStarter) {
        const inc: RaceIncidentRecord = {
          type: 'false_start',
          code: 'FALSE_START_UNDER_100MS',
          athleteId: falseStarter.ath.athleteId,
          lane: falseStarter.ath.lane,
          attempt: attemptIdx,
          atTime: falseStarter.atTime,
          detail: `${falseStarter.ath.name} (Lane ${falseStarter.ath.lane}) reacted at ${falseStarter.atTime.toFixed(
            3
          )}s (< 0.100s threshold).`,
        };
        attemptIncidents.push(inc);
        allIncidents.push(inc);

        if (setup.rules.falseStartDisqualifies) {
          dqMap.set(falseStarter.ath.athleteId, {
            attempt: attemptIdx,
            reason: 'false_start',
          });
          activeRoster = activeRoster.filter(
            (a) => a.athleteId !== falseStarter!.ath.athleteId
          );
        }

        attempts.push({
          attemptIndex: attemptIdx,
          holdDurationSec,
          activeAthleteIds: [
            ...activeRoster.map((a) => a.athleteId),
            ...(setup.rules.falseStartDisqualifies
              ? [falseStarter.ath.athleteId]
              : []),
          ],
          recalled: true,
          recallReason: 'false_start',
          recallAtTimeSec: Math.max(0.25, falseStarter.atTime + 0.35),
          offendingAthleteId: falseStarter.ath.athleteId,
          incidents: attemptIncidents,
        });
        attemptIdx++;
        continue;
      }

      // Clean start!
      attempts.push({
        attemptIndex: attemptIdx,
        holdDurationSec,
        activeAthleteIds: activeRoster.map((a) => a.athleteId),
        recalled: false,
        incidents: [],
      });
      break;
    }

    const finalAttemptIndex = attempts[attempts.length - 1].attemptIndex;

    // 4. Plan the actual clean race physics & in-race incidents
    interface RunnerPhysicsSpec {
      ath: AthleteSetup;
      reactionTime: number;
      maxSpeed: number;
      accelRate: number;
      fadeRate: number;
      stumbledStart: boolean;
      stumbleLoss: number;
      fallAtDist: number | null;
      injuryAtDist: number | null;
      laneViolation: boolean;
      breakout: boolean;
      collisionAtDist: number | null;
      notes: string[];
    }

    const specs = new Map<string, RunnerPhysicsSpec>();

    // Wind assists tailwind slightly (~0.045 s per 1.0 m/s -> ~0.5% speed boost per m/s)
    const windSpeedMult = 1 + windMps * 0.0046;

    activeRoster.forEach((ath) => {
      const r = ath.ratings;
      const formFactor = rng.gaussian(0, 0.008 * (1.25 - r.consistency / 120));
      const breakout = rng.next() < rates.breakoutPerformanceRate;
      const notes: string[] = [];

      // Reaction time: ~0.120 - 0.215s
      const baseReact = 0.205 - (r.reaction / 100) * 0.078;
      const reactNoise = rng.gaussian(0, 0.011 * (1.2 - r.composure / 140));
      const reactionTime = roundTo(clamp(baseReact + reactNoise, 0.112, 0.235), 3);

      // Top speed: ~11.30 - 12.25 m/s (elite winning ~9.78 - 10.18 s, field up to ~10.6s)
      const baseTopSpeed = 10.22 + (r.topSpeed / 100) * 1.82;
      const breakoutBoost = breakout ? rng.range(0.14, 0.24) : 0;
      const maxSpeed = clamp(
        (baseTopSpeed + breakoutBoost) * windSpeedMult * (1 + formFactor),
        10.5,
        12.45
      );

      // Acceleration drive constant (calibrated so 20m ~2.88-3.10s, peak speed ~55-65m)
      const accelRate =
        0.52 + (r.acceleration / 100) * 0.21 + (r.technique / 100) * 0.07;

      // Late-race fade beyond 60m (lower fadeRate = better speed endurance)
      const fadeRate = Math.max(
        0.014,
        0.078 - (r.speedEndurance / 100) * 0.056
      );

      // In-race incidents
      const stumbleProb =
        rates.stumbledStartRate * (1.4 - r.technique / 110);
      const stumbledStart = rng.next() < stumbleProb;
      const stumbleLoss = stumbledStart ? rng.range(0.22, 0.42) : 0;

      const fallProb =
        rates.fallOrTripRate * (1.5 - (r.technique + r.composure) / 160);
      const willFall = rng.next() < fallProb;
      const fallAtDist = willFall ? roundTo(rng.range(6, 26), 1) : null;

      const injuryProb =
        rates.injuryPullUpRate *
        (1.45 - r.durability / 110) *
        (0.85 + r.topSpeed / 250);
      const willInjure = !willFall && rng.next() < injuryProb;
      const injuryAtDist = willInjure ? roundTo(rng.range(38, 82), 1) : null;

      const laneViolationProb =
        rates.laneViolationRate * (1.4 - r.technique / 115);
      const laneViolation =
        !willFall && !willInjure && rng.next() < laneViolationProb;

      if (breakout) {
        notes.push('Breakout performance');
        allIncidents.push({
          type: 'great_performance',
          code: 'BREAKOUT_RUN',
          athleteId: ath.athleteId,
          lane: ath.lane,
          attempt: finalAttemptIndex,
          atTime: 5.5,
          detail: `${ath.name} hit peak stride mechanics for an inspired run!`,
        });
      }
      if (stumbledStart) {
        notes.push('Stumbled start');
        allIncidents.push({
          type: 'stumbled_start',
          code: 'BLOCK_STUMBLE',
          athleteId: ath.athleteId,
          lane: ath.lane,
          attempt: finalAttemptIndex,
          atTime: roundTo(reactionTime + 0.35, 3),
          detail: `${ath.name} lost traction leaving the blocks in Lane ${ath.lane}.`,
        });
      }

      specs.set(ath.athleteId, {
        ath,
        reactionTime,
        maxSpeed,
        accelRate,
        fadeRate,
        stumbledStart,
        stumbleLoss,
        fallAtDist,
        injuryAtDist,
        laneViolation,
        breakout,
        collisionAtDist: null,
        notes,
      });
    });

    // Check rare adjacent-lane collision brush if a runner stumbled or had lane violation
    activeRoster.forEach((ath) => {
      const sp = specs.get(ath.athleteId)!;
      if (sp.stumbledStart || sp.laneViolation) {
        const neighbor = activeRoster.find(
          (other) => Math.abs(other.lane - ath.lane) === 1
        );
        if (neighbor && rng.next() < rates.collisionBrushRate * 6) {
          const nSpec = specs.get(neighbor.athleteId)!;
          const brushDist = roundTo(rng.range(18, 45), 1);
          sp.collisionAtDist = brushDist;
          nSpec.collisionAtDist = brushDist;
          sp.notes.push('Lane brush');
          nSpec.notes.push('Brushed by adjacent runner');
          allIncidents.push({
            type: 'collision',
            code: 'LANE_BRUSH_CONTACT',
            athleteId: ath.athleteId,
            lane: ath.lane,
            attempt: finalAttemptIndex,
            atTime: roundTo(brushDist / 8.5, 2),
            detail: `Slight shoulder brush between Lane ${ath.lane} (${ath.shortName}) and Lane ${neighbor.lane} (${neighbor.shortName}).`,
          });
        }
      }
    });

    // 5. Integrate physics at high-res substeps and record 1/30s frames
    const maxSimSeconds = 15.0; // enough for slow/limping/victory deceleration
    const numFrames = Math.ceil(maxSimSeconds * FIXED_HZ);

    const athleteRuns = new Map<string, PlannedAthleteRun>();
    const dist40Snapshot = new Map<string, number>();
    const dist75Snapshot = new Map<string, number>();

    setup.athletes.forEach((ath) => {
      const isInitialDns = ath.status === 'dns';
      const isLateDns = lateDnsSet.has(ath.athleteId);
      const dqEntry = dqMap.get(ath.athleteId);

      if (isInitialDns || isLateDns || dqEntry) {
        athleteRuns.set(ath.athleteId, {
          athlete: ath,
          initialDns: isInitialDns,
          lateDns: isLateDns,
          dqOnAttempt: dqEntry?.attempt,
          reactionTimeSec: 0,
          topSpeedMps: 0,
          splits: { '20': 0, '40': 0, '60': 0, '80': 0 },
          exactFinishTimeSec: null,
          displayFinishTimeSec: null,
          status: dqEntry ? 'DQ' : 'DNS',
          reason: dqEntry ? dqEntry.reason : isLateDns ? 'late_withdrawal' : 'dns',
          notes: dqEntry
            ? [`Disqualified (Attempt #${dqEntry.attempt + 1}): ${dqEntry.reason}`]
            : [isLateDns ? 'Late call-room withdrawal' : 'Did not start'],
          frames: [],
        });
        return;
      }

      const sp = specs.get(ath.athleteId)!;
      let dist = 0;
      let speed = 0;
      let peakSpeed = 0;
      let fallen = false;
      let fallTimer = 0;
      let injured = false;
      let injuryTimer = 0;
      let collisionTriggered = false;
      let laneViolationLogged = false;
      let finishTimeExact: number | null = null;

      const splitCross: Record<'20' | '40' | '60' | '80', number> = {
        '20': 0,
        '40': 0,
        '60': 0,
        '80': 0,
      };
      const frames: AthleteFrameSample[] = [];

      for (let f = 0; f <= numFrames; f++) {
        const frameTime = f * FIXED_DT;

        // Snapshot at 4.5s & 7.4s for commentary
        if (Math.abs(frameTime - 4.5) < FIXED_DT * 0.6) {
          dist40Snapshot.set(ath.athleteId, dist);
        }
        if (Math.abs(frameTime - 7.4) < FIXED_DT * 0.6) {
          dist75Snapshot.set(ath.athleteId, dist);
        }

        // Determine pose for this frame
        let pose: AthletePoseAction = 'sprint';
        if (frameTime < sp.reactionTime) {
          pose = 'set_crouch';
        } else if (fallen) {
          pose = 'fall_slide';
        } else if (injured) {
          pose = speed > 1.2 ? 'pull_up_injured' : 'limp';
        } else if (
          sp.stumbledStart &&
          frameTime >= sp.reactionTime + 0.1 &&
          frameTime <= sp.reactionTime + 0.85
        ) {
          pose = 'stumble';
        } else if (dist >= 97.5 && dist <= 101.2 && finishTimeExact !== null ? frameTime < finishTimeExact + 0.2 : dist >= 97.5 && dist <= 100.5) {
          pose = 'lean_finish';
        } else if (finishTimeExact !== null && frameTime > finishTimeExact + 1.6) {
          pose = 'disappointed'; // Updated after ranking for winner -> celebrate!
        }

        const lateralOffsetM = sp.laneViolation
          ? Math.sin(clamp((dist - 40) / 30, 0, 1) * Math.PI) * 0.68
          : 0;

        frames.push({
          distanceM: dist,
          speedMps: speed,
          lateralOffsetM,
          pose,
        });

        // Step physics for next frame
        for (let s = 0; s < SUBSTEPS; s++) {
          const tNow = frameTime + s * SUB_DT;
          if (tNow < sp.reactionTime) {
            speed = 0;
            continue;
          }

          if (!fallen && sp.fallAtDist !== null && dist >= sp.fallAtDist) {
            fallen = true;
            fallTimer = 0;
            allIncidents.push({
              type: 'fall',
              code: 'IN_RACE_FALL',
              athleteId: ath.athleteId,
              lane: ath.lane,
              attempt: finalAttemptIndex,
              atTime: roundTo(tNow, 2),
              detail: `${ath.name} tripped at ${dist.toFixed(1)}m and slid to a halt (DNF).`,
            });
          }

          if (!injured && !fallen && sp.injuryAtDist !== null && dist >= sp.injuryAtDist) {
            injured = true;
            injuryTimer = 0;
            allIncidents.push({
              type: 'injury',
              code: 'HAMSTRING_PULL_UP',
              athleteId: ath.athleteId,
              lane: ath.lane,
              attempt: finalAttemptIndex,
              atTime: roundTo(tNow, 2),
              detail: `${ath.name} suffered a hamstring pull at ${dist.toFixed(1)}m and pulled up (DNF).`,
            });
          }

          if (
            !laneViolationLogged &&
            sp.laneViolation &&
            dist >= 55 &&
            !fallen &&
            !injured
          ) {
            laneViolationLogged = true;
            sp.notes.push('Lane infringement');
            allIncidents.push({
              type: 'lane_violation',
              code: 'LANE_LINE_CROSSING',
              athleteId: ath.athleteId,
              lane: ath.lane,
              attempt: finalAttemptIndex,
              atTime: roundTo(tNow, 2),
              detail: `${ath.name} stepped over the lane line near ${dist.toFixed(0)}m (DQ).`,
            });
          }

          if (
            !collisionTriggered &&
            sp.collisionAtDist !== null &&
            dist >= sp.collisionAtDist
          ) {
            collisionTriggered = true;
            speed *= 0.86;
          }

          if (fallen) {
            fallTimer += SUB_DT;
            speed = Math.max(0, speed - 7.5 * SUB_DT);
          } else if (injured) {
            injuryTimer += SUB_DT;
            speed = Math.max(0, speed - 4.2 * SUB_DT);
            if (injuryTimer > 2.4) speed = 0;
          } else if (finishTimeExact !== null) {
            // Post-finish smooth deceleration
            const after = tNow - finishTimeExact;
            if (after < 0.4) {
              speed = Math.max(0, speed - 1.5 * SUB_DT);
            } else {
              speed = Math.max(0, speed - 4.4 * SUB_DT);
            }
          } else {
            // Active sprint physics
            const sinceReact = tNow - sp.reactionTime;
            let targetTop = sp.maxSpeed;
            if (sp.stumbledStart && sinceReact < 1.1) {
              targetTop *= 1 - sp.stumbleLoss * (1 - sinceReact / 1.1);
            }
            // Late fade beyond 62m
            const fadeDist = Math.max(0, dist - 62);
            const fadedTarget = targetTop * (1 - sp.fadeRate * (fadeDist / 38));
            const dv = (fadedTarget - speed) * sp.accelRate * SUB_DT;
            speed = Math.max(0, speed + dv);
          }

          if (speed > peakSpeed) peakSpeed = speed;

          const prevDist = dist;
          dist += speed * SUB_DT;

          // Record exact split crossings
          ([20, 40, 60, 80] as const).forEach((mark) => {
            const key = String(mark) as '20' | '40' | '60' | '80';
            if (splitCross[key] === 0 && prevDist < mark && dist >= mark) {
              const frac = (mark - prevDist) / Math.max(1e-6, dist - prevDist);
              splitCross[key] = roundTo(tNow + frac * SUB_DT, 2);
            }
          });

          if (finishTimeExact === null && prevDist < 100 && dist >= 100) {
            const frac = (100 - prevDist) / Math.max(1e-6, dist - prevDist);
            finishTimeExact = roundTo(tNow + frac * SUB_DT, 3);
          }
        }
      }

      let status: 'finished' | 'DQ' | 'DNF' = 'finished';
      let reason: string | undefined;
      if (fallen) {
        status = 'DNF';
        reason = 'fall';
      } else if (injured) {
        status = 'DNF';
        reason = 'injury';
      } else if (sp.laneViolation) {
        status = 'DQ';
        reason = 'lane_violation';
      }

      if (status === 'finished' && ath.personalBest && finishTimeExact && finishTimeExact < ath.personalBest) {
        sp.notes.push(`New PB (${finishTimeExact.toFixed(2)}s)`);
      }

      athleteRuns.set(ath.athleteId, {
        athlete: ath,
        initialDns: false,
        lateDns: false,
        reactionTimeSec: sp.reactionTime,
        topSpeedMps: roundTo(peakSpeed, 2),
        splits: splitCross,
        exactFinishTimeSec: status === 'finished' ? finishTimeExact : null,
        displayFinishTimeSec:
          status === 'finished' && finishTimeExact !== null
            ? roundTo(finishTimeExact, 2)
            : null,
        status,
        reason,
        notes: sp.notes,
        frames,
      });
    });

    // 6. Rank finishers by exact 0.001 s time
    const allRuns = Array.from(athleteRuns.values());
    const finishers = allRuns
      .filter((r) => r.status === 'finished' && r.exactFinishTimeSec !== null)
      .sort((a, b) => a.exactFinishTimeSec! - b.exactFinishTimeSec!);

    const winnerId = finishers[0]?.athlete.athleteId;
    if (winnerId) {
      const wRun = athleteRuns.get(winnerId)!;
      wRun.frames.forEach((fr, idx) => {
        if (wRun.exactFinishTimeSec && idx * FIXED_DT > wRun.exactFinishTimeSec + 1.5) {
          fr.pose = 'celebrate';
        }
      });
    }

    const rankById = new Map<string, number>();
    finishers.forEach((r, idx) => rankById.set(r.athlete.athleteId, idx + 1));

    const results: AthleteRaceResult[] = allRuns
      .slice()
      .sort((a, b) => {
        const ra = rankById.get(a.athlete.athleteId);
        const rb = rankById.get(b.athlete.athleteId);
        if (ra !== undefined && rb !== undefined) return ra - rb;
        if (ra !== undefined) return -1;
        if (rb !== undefined) return 1;
        return a.athlete.lane - b.athlete.lane;
      })
      .map((run) => {
        const rank = rankById.get(run.athlete.athleteId) ?? null;
        if (run.status === 'finished') {
          return {
            rank,
            lane: run.athlete.lane,
            athleteId: run.athlete.athleteId,
            name: run.athlete.name,
            shortName: run.athlete.shortName,
            nation: run.athlete.nation,
            nationCode: run.athlete.nationCode,
            bib: run.athlete.bib,
            time: run.displayFinishTimeSec ?? undefined,
            exactTime: run.exactFinishTimeSec ?? undefined,
            reactionTime: run.reactionTimeSec,
            splits: { ...run.splits },
            topSpeedMps: run.topSpeedMps,
            status: 'finished',
            notes: [...run.notes],
          };
        }
        return {
          rank: null,
          lane: run.athlete.lane,
          athleteId: run.athlete.athleteId,
          name: run.athlete.name,
          shortName: run.athlete.shortName,
          nation: run.athlete.nation,
          nationCode: run.athlete.nationCode,
          bib: run.athlete.bib,
          reactionTime: run.reactionTimeSec > 0 ? run.reactionTimeSec : undefined,
          status: run.status,
          reason: run.reason,
          notes: [...run.notes],
        };
      });

    // Total sim duration = last finisher + 3.2s celebration/walk-off (clamped)
    const lastFinish =
      finishers.length > 0
        ? finishers[finishers.length - 1].exactFinishTimeSec ?? 10.5
        : 10.5;
    const totalSimDurationSec = Math.min(maxSimSeconds, Math.max(11.5, lastFinish + 3.0));

    // Commentary leaders
    const findLeader = (snap: Map<string, number>) => {
      let bestAth: AthleteSetup | undefined;
      let bestDist = -1;
      snap.forEach((d, id) => {
        if (d > bestDist) {
          bestDist = d;
          bestAth = setup.athletes.find((a) => a.athleteId === id);
        }
      });
      return bestAth;
    };

    const sortedIncidents = allIncidents
      .slice()
      .sort((a, b) => a.attempt - b.attempt || a.atTime - b.atTime);

    const commentaryCtx = {
      setup,
      windMps,
      windLegal,
      incidents: sortedIncidents,
      results,
    };

    const commentaryCues = this.commentary.generateRaceCues(
      commentaryCtx,
      findLeader(dist40Snapshot),
      findLeader(dist75Snapshot),
      rng
    );
    const postRaceSummary = this.commentary.generatePostRaceSummary(commentaryCtx);

    const resultsPayload: RaceResultsPayload = {
      raceId: setup.raceId,
      seed: setup.seed,
      completedAt: new Date().toISOString(),
      wind: { mps: windMps, legal: windLegal },
      incidents: sortedIncidents,
      results: results.map((r) => ({
        ...r,
        // Keep exactTime for photo-finish resolution but match API contract cleanly
      })),
    };

    return {
      setup,
      seed: setup.seed,
      windMps,
      windLegal,
      attempts,
      finalAttemptIndex,
      totalSimDurationSec,
      athleteRuns,
      incidents: sortedIncidents,
      results,
      resultsPayload,
      laneIntros,
      commentaryCues,
      postRaceSummary,
    };
  }
}

export function sampleAthleteFrame(
  run: PlannedAthleteRun,
  raceTimeSec: number
): AthleteFrameSample {
  if (run.frames.length === 0) {
    return { distanceM: 0, speedMps: 0, lateralOffsetM: 0, pose: 'disappointed' };
  }
  if (raceTimeSec <= 0) {
    return run.frames[0];
  }
  const exactIdx = raceTimeSec * FIXED_HZ;
  const i0 = Math.min(run.frames.length - 1, Math.floor(exactIdx));
  const i1 = Math.min(run.frames.length - 1, i0 + 1);
  const alpha = exactIdx - i0;
  const f0 = run.frames[i0];
  const f1 = run.frames[i1];
  return {
    distanceM: f0.distanceM + (f1.distanceM - f0.distanceM) * alpha,
    speedMps: f0.speedMps + (f1.speedMps - f0.speedMps) * alpha,
    lateralOffsetM: f0.lateralOffsetM + (f1.lateralOffsetM - f0.lateralOffsetM) * alpha,
    pose: f0.pose,
  };
}
