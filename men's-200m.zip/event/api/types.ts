import type { IncidentConfigRates } from '../config/incidents';

export type RaceState =
  | 'WAITING_FOR_API'
  | 'SETUP_RECEIVED'
  | 'VALIDATED'
  | 'ATHLETES_ON_TRACK'
  | 'READY'
  | 'ON_YOUR_MARKS'
  | 'SET'
  | 'RUNNING'
  | 'FALSE_START_RECALL'
  | 'FINISHED'
  | 'RESULTS_POSTED';

export interface AthleteKit {
  primary: string;
  secondary: string;
  accent: string;
}

export interface AthleteRatings {
  reaction: number;
  acceleration: number;
  topSpeed: number;
  speedEndurance: number;
  consistency: number;
  composure: number;
  durability: number;
  technique: number;
}

export type AthleteInitialStatus = 'active' | 'dns';

export interface AthleteSetup {
  athleteId: string;
  lane: number;
  name: string;
  shortName: string;
  nation: string;
  nationCode: string;
  bib: string;
  kit: AthleteKit;
  ratings: AthleteRatings;
  personalBest?: number;
  seasonBest?: number;
  status: AthleteInitialStatus;
}

export interface RaceRules {
  falseStartDisqualifies: boolean;
  windLimitMps: number;
}

export interface RaceSetupPayload {
  raceId: string;
  event: 'men_100m';
  round: string;
  heat: number;
  seed: number;
  scheduledStartTime?: string | null;
  allowManualStart: boolean;
  venue: string;
  rules: RaceRules;
  incidentOverrides?: Partial<IncidentConfigRates> | null;
  athletes: AthleteSetup[];
}

export type RaceCommand =
  | { command: 'start'; issuedAt: string }
  | { command: 'abort'; reason?: string }
  | { command: 'reset' };

export interface RaceStatusUpdate {
  status: string;
  athleteId?: string;
  detail?: string;
  timestamp?: string;
}

export type IncidentType =
  | 'false_start'
  | 'stumbled_start'
  | 'fall'
  | 'injury'
  | 'lane_violation'
  | 'collision'
  | 'late_dns'
  | 'equipment_issue'
  | 'great_performance';

export interface RaceIncidentRecord {
  type: IncidentType;
  code: string;
  athleteId: string | null;
  lane: number | null;
  attempt: number;
  atTime: number;
  detail: string;
}

export type AthleteResultStatus = 'finished' | 'DQ' | 'DNF' | 'DNS';

export interface AthleteRaceResult {
  rank: number | null;
  lane: number;
  athleteId: string;
  name: string;
  shortName: string;
  nation: string;
  nationCode: string;
  bib: string;
  time?: number;
  exactTime?: number;
  reactionTime?: number;
  splits?: {
    '20': number;
    '40': number;
    '60': number;
    '80': number;
  };
  topSpeedMps?: number;
  status: AthleteResultStatus;
  reason?: string;
  notes: string[];
}

export interface RaceResultsPayload {
  raceId: string;
  seed: number;
  completedAt: string;
  wind: {
    mps: number;
    legal: boolean;
  };
  incidents: RaceIncidentRecord[];
  results: AthleteRaceResult[];
}
