import type { IncidentConfigRates } from '../config/incidents';
import type {
  RaceCommand,
  RaceResultsPayload,
  RaceSetupPayload,
  RaceStatusUpdate,
} from './types';
import type { WavesportsApiClient } from './WavesportsApiClient';

const SAMPLE_SETUP: RaceSetupPayload = {
  raceId: 'men-100m-final-1',
  event: 'men_100m',
  round: 'final',
  heat: 1,
  seed: 482913,
  scheduledStartTime: null,
  allowManualStart: true,
  venue: 'Klemonserrat Stadium',
  rules: {
    falseStartDisqualifies: true,
    windLimitMps: 2.0,
  },
  incidentOverrides: null,
  athletes: [
    {
      athleteId: 'ath_001',
      lane: 1,
      name: 'Kitione Wari',
      shortName: 'WARI',
      nation: 'Papua New Guinea',
      nationCode: 'PNG',
      bib: '101',
      kit: { primary: '#CE1126', secondary: '#FCD116', accent: '#111827' },
      ratings: {
        reaction: 74,
        acceleration: 79,
        topSpeed: 82,
        speedEndurance: 78,
        consistency: 77,
        composure: 75,
        durability: 80,
        technique: 76,
      },
      personalBest: 10.18,
      seasonBest: 10.24,
      status: 'active',
    },
    {
      athleteId: 'ath_002',
      lane: 2,
      name: 'Ratu Jone Naisara',
      shortName: 'NAISARA',
      nation: 'Fiji',
      nationCode: 'FIJ',
      bib: '102',
      kit: { primary: '#002868', secondary: '#68BFE5', accent: '#FFFFFF' },
      ratings: {
        reaction: 79,
        acceleration: 83,
        topSpeed: 86,
        speedEndurance: 81,
        consistency: 80,
        composure: 78,
        durability: 82,
        technique: 81,
      },
      personalBest: 10.04,
      seasonBest: 10.09,
      status: 'active',
    },
    {
      athleteId: 'ath_003',
      lane: 3,
      name: 'Sione Vaioleti',
      shortName: 'VAIOLETI',
      nation: 'Tonga',
      nationCode: 'TON',
      bib: '103',
      kit: { primary: '#C10000', secondary: '#FFFFFF', accent: '#F5C542' },
      ratings: {
        reaction: 82,
        acceleration: 88,
        topSpeed: 89,
        speedEndurance: 84,
        consistency: 83,
        composure: 80,
        durability: 84,
        technique: 85,
      },
      personalBest: 9.96,
      seasonBest: 10.01,
      status: 'active',
    },
    {
      athleteId: 'ath_004',
      lane: 4,
      name: 'Kaelen Tuiasosopo',
      shortName: 'TUIASOSOPO',
      nation: 'New Pleadland',
      nationCode: 'NPL',
      bib: '104',
      kit: { primary: '#0033A0', secondary: '#FFFFFF', accent: '#D4AF37' },
      ratings: {
        reaction: 86,
        acceleration: 91,
        topSpeed: 94,
        speedEndurance: 89,
        consistency: 88,
        composure: 85,
        durability: 86,
        technique: 90,
      },
      personalBest: 9.84,
      seasonBest: 9.89,
      status: 'active',
    },
    {
      athleteId: 'ath_005',
      lane: 5,
      name: 'Liam Henderson',
      shortName: 'HENDERSON',
      nation: 'Australia',
      nationCode: 'AUS',
      bib: '105',
      kit: { primary: '#00843D', secondary: '#FFCD00', accent: '#FFFFFF' },
      ratings: {
        reaction: 84,
        acceleration: 89,
        topSpeed: 93,
        speedEndurance: 90,
        consistency: 87,
        composure: 86,
        durability: 85,
        technique: 89,
      },
      personalBest: 9.87,
      seasonBest: 9.91,
      status: 'active',
    },
    {
      athleteId: 'ath_006',
      lane: 6,
      name: 'Tane Te Aho',
      shortName: 'TE AHO',
      nation: 'New Zealand',
      nationCode: 'NZL',
      bib: '106',
      kit: { primary: '#111827', secondary: '#FFFFFF', accent: '#94A3B8' },
      ratings: {
        reaction: 81,
        acceleration: 86,
        topSpeed: 90,
        speedEndurance: 86,
        consistency: 84,
        composure: 82,
        durability: 83,
        technique: 86,
      },
      personalBest: 9.94,
      seasonBest: 9.98,
      status: 'active',
    },
    {
      athleteId: 'ath_007',
      lane: 7,
      name: 'Malakai Ravouvou',
      shortName: 'RAVOUVOU',
      nation: 'Samoa',
      nationCode: 'SAM',
      bib: '107',
      kit: { primary: '#002B7F', secondary: '#CE1126', accent: '#FFFFFF' },
      ratings: {
        reaction: 77,
        acceleration: 84,
        topSpeed: 87,
        speedEndurance: 82,
        consistency: 79,
        composure: 74,
        durability: 81,
        technique: 80,
      },
      personalBest: 10.05,
      seasonBest: 10.11,
      status: 'active',
    },
    {
      athleteId: 'ath_008',
      lane: 8,
      name: 'Reuben Manuleleua',
      shortName: 'MANULELEUA',
      nation: 'Solomon Islands',
      nationCode: 'SOL',
      bib: '108',
      kit: { primary: '#0051BA', secondary: '#215B33', accent: '#FCD116' },
      ratings: {
        reaction: 75,
        acceleration: 80,
        topSpeed: 84,
        speedEndurance: 79,
        consistency: 78,
        composure: 77,
        durability: 82,
        technique: 78,
      },
      personalBest: 10.15,
      seasonBest: 10.21,
      status: 'active',
    },
  ],
};

/**
 * Dev-only Mock Wavesports API implementation.
 * Disabled and excluded from production behavior when `import.meta.env.DEV` is false.
 */
export class MockWavesportsApi implements WavesportsApiClient {
  public readonly modeLabel = 'MOCK API – DEV ONLY';
  public readonly isMock = true;

  private commandQueue: RaceCommand[] = [];
  private statusHistory: RaceStatusUpdate[] = [];
  private lastResults: RaceResultsPayload | null = null;
  private seedOverride: number | null;
  private cleanRace: boolean;

  constructor(options?: { seedOverride?: number | null; cleanRace?: boolean }) {
    if (!import.meta.env.DEV) {
      throw new Error('MockWavesportsApi is strictly disabled in production builds.');
    }
    this.seedOverride = options?.seedOverride ?? null;
    this.cleanRace = Boolean(options?.cleanRace);
  }

  public enqueueCommand(command: RaceCommand): void {
    this.commandQueue.push(command);
  }

  public setSeed(seed: number): void {
    this.seedOverride = Math.round(seed);
  }

  public getStatusHistory(): RaceStatusUpdate[] {
    return [...this.statusHistory];
  }

  public getLastResults(): RaceResultsPayload | null {
    return this.lastResults;
  }

  public async fetchSetup(raceId: string): Promise<RaceSetupPayload> {
    await new Promise((r) => setTimeout(r, 220));
    const incidentOverrides: Partial<IncidentConfigRates> | null = this.cleanRace
      ? {
          falseStartBaseRate: 0,
          stumbledStartRate: 0,
          fallOrTripRate: 0,
          injuryPullUpRate: 0,
          laneViolationRate: 0,
          collisionBrushRate: 0,
          lateDnsRate: 0,
          equipmentBlockSlipRate: 0,
        }
      : null;

    return {
      ...SAMPLE_SETUP,
      raceId: raceId || SAMPLE_SETUP.raceId,
      seed: this.seedOverride ?? SAMPLE_SETUP.seed,
      incidentOverrides,
      athletes: SAMPLE_SETUP.athletes.map((a) => ({
        ...a,
        kit: { ...a.kit },
        ratings: { ...a.ratings },
      })),
    };
  }

  public async pollCommands(): Promise<RaceCommand[]> {
    if (this.commandQueue.length === 0) return [];
    const items = [...this.commandQueue];
    this.commandQueue = [];
    return items;
  }

  public async postStatus(_raceId: string, update: RaceStatusUpdate): Promise<void> {
    this.statusHistory.push({
      ...update,
      timestamp: update.timestamp ?? new Date().toISOString(),
    });
  }

  public async postResults(_raceId: string, results: RaceResultsPayload): Promise<void> {
    this.lastResults = results;
    console.info('[MockWavesportsApi] Results received:', results);
  }
}
