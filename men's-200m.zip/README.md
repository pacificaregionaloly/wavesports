# Klemonserrat Stadium 3D — 1st Pacifica Regional Olympics 2026 (WSTV)

Interactive 3D architectural and athletic venue web application for **Klemonserrat Stadium** (Plead City, New Pleadland), main track venue of the **1st Pacifica Regional Olympics 2026**, broadcast by **Wavesports Television (WSTV)**.

Everything in the 3D scene—track geometry, surface textures, lane lines, turf stripes, seating bowl, roof canopy, facade, flags, crests, spectators, officials, warm-up runners, and video boards—is procedurally generated in code with zero external model or texture downloads.

---

## Running & Building Static Site

```bash
# Install dependencies
npm install

# Run local development server (http://localhost:3000)
npm run dev

# Build static production bundle (outputs plain HTML/JS/CSS into dist/)
npm run build
```

The production build in `dist/` is a self-contained static site ready for any static host (S3, Netlify, Vercel, GitHub Pages, Nginx) or `<iframe>` embed.

### Iframe Embedding

```html
<iframe
  src="https://your-host.example/klemonserrat-stadium/"
  width="100%"
  height="680"
  style="border: 0;"
  allowfullscreen
></iframe>
```

---

## 400.00 m Closed-Loop Track Self-Check

At startup, `src/track/TrackBuilder.ts` constructs the entire 8-lane World Athletics regulation oval as one closed loop:
- **Two straights**: `84.39 m` each (`HALF_STRAIGHT = 42.195 m`)
- **Lane 1 measuring radius**: `36.80 m` (inner kerb outer face at `36.50 m`)
- **8 lanes × `1.22 m` width** with continuous `5 cm` white lane lines, lane numbers `1–8` at the home straight start, and a single Finish Line + gantry + photo-finish post

From the generated closed-loop `sampleClosedOvalPoints(36.80, 96)` vertices, `computePolylineLapLength()` verifies:
- **Analytical length**: `2 * 84.39 + 2 * π * 36.80 = 400.0012 m`
- **Generated polyline self-check**: `399.997 m – 400.001 m` (within `400.00 m ± 0.01 m`), logged at startup and displayed live in the top-left HUD badge. Use the **400m Loop** toggle in the top bar to inspect the closed `THREE.LineLoop` centerline overlay directly in 3D.

---

## Swapping Logos & Athlete GLB Model

### 1. Swapping Branding Textures (`src/config/index.ts`)
Replace any `null` slot inside `STADIUM_CONFIG.brandingSlots` with a PNG/SVG/WebP URL or data URI to override the procedural canvas generator without touching scene code:

```ts
brandingSlots: {
  newPleadlandFlagUrl: '/assets/my-flag.png',
  pacificaEmblemUrl: '/assets/my-emblem.png',
  wstvLogoUrl: '/assets/my-wstv.png',
  customAthleteGlbUrl: null,
}
```

### 2. Swapping the Athlete 3D Model (`src/people/PersonFactory.ts`)
Use `loadCustomAthleteModel(url)` in `src/people/PersonFactory.ts` (or set `STADIUM_CONFIG.brandingSlots.customAthleteGlbUrl`) to load a custom `.glb` athlete mesh via `GLTFLoader` in place of the procedural articulated figure.

---

## Video Boards & Scoreboard Sources (`BoardScreen`)

Four live screens are mounted inside the stadium (`eastBoard`, `westBoard`, `ringBoard`, `mainScoreboard`). Use the **Boards & Text** button in the top-right bar to write custom headlines and announcements directly onto any or all boards, or switch each board across 6 runtime sources:

| Source | Description |
| :--- | :--- |
| `message` | Custom headline, multi-line body announcement, theme, and scrolling 360° ring marquee |
| `demo` | Animated 2D oval track dot loop, 8-lane Pacifica lineup, and live running clock |
| `canvas2d` | Custom per-frame `draw(ctx, width, height, elapsed)` 2D canvas feed |
| `video` | Live `HTMLVideoElement` via `THREE.VideoTexture` (pass `video`, `videoUrl`, or use built-in canvas stream) |
| `renderTarget` | Live secondary Three.js `WebGLRenderTarget` 3D scene feed |
| `postMessage` | External iframe / parent data via `window.postMessage({ type: 'wstv-board', ... }, '*')` |

---

## Extension API (`window.WSTV.stadium`)

The stadium publishes a modular API on both `window.WSTV.stadium` and `getStadiumAPI()` (`src/api/StadiumAPI.ts`) so external race/event modules can drive runners and boards cleanly:

```ts
const stadium = window.WSTV.stadium;

// 1. Query closed 400m track coordinates for any lane (1..8)
const lane1 = stadium.getTrackPath(1);
const pt = lane1.pointAt(125.0); // { position: Vector3, heading: number, tangent: Vector3 }

// 2. Write a custom announcement to one or all stadium boards
stadium.boards.writeMessage('all', {
  title: 'WELCOME TO KLEMONSERRAT STADIUM',
  body: '1st Pacifica Regional Olympics 2026 — Live from Plead City',
  theme: 'royal',
});

// 2. Spawn or animate people / runners
const id = stadium.people.spawnPerson('runner', { name: 'A. Runner', pose: 'idle' });
stadium.people.setPose(id, 'warmup');

// 3. Hook per-frame simulation updates
const stop = stadium.addUpdateCallback((elapsed, dt) => {
  // update custom entities
});

// 4. Switch any LED board to custom Canvas 2D, Video, RenderTarget, or postMessage
stadium.boards.get('mainScoreboard')?.setSource('canvas2d', {
  draw: (ctx, w, h, t) => { /* custom broadcast graphics */ },
});

// 5. Camera presets & time of day & plain JSON state
stadium.cameras.goTo('finishLine');
stadium.setTimeOfDay('night');
console.log(stadium.state);
```

---

## Module Structure

- `src/config/index.ts` — All track dimensions, bowl counts, colors, camera presets, and branding slots
- `src/track/` — Regulation closed-loop geometry, `getTrackPath`, and `TrackBuilder` self-check
- `src/stadium/` — `Environment` (sky, Pacific Ocean, lighting, floodlights), `StadiumStructure` (40k bowl, wave canopy, facade, plaza, torch), and `SceneController`
- `src/branding/` — Procedural Canvas/SVG crests, New Pleadland flag, Pacifica emblem, WSTV logo, ad boards
- `src/crowd/` — Instanced 18,000-spectator crowd + shader-animated hand flags
- `src/people/` — Shared `Person` factory + `PeopleManager` (officials, staff, media, warm-up runners)
- `src/boards/` — `BoardScreen` and `BoardManager` (5 runtime sources + secondary `WebGLRenderTarget`)
- `src/cameras/` — `OrbitControls` + 8 smooth camera presets + auto-orbit
- `src/api/` — Extension API (`window.WSTV.stadium`)
- `src/ui/` — HUD controls, Boards Source Switcher panel, and WebGL fallback
