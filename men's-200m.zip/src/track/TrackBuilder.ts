import * as THREE from 'three';
import {
  createInfieldTurfTexture,
  createLaneNumberTexture,
  createTrackSurfaceTexture,
} from '../branding/textures';
import { STADIUM_CONFIG } from '../config';
import {
  computePolylineLapLength,
  getLaneMetrics,
  HALF_STRAIGHT,
  KERB_RADIUS,
  OUTER_TRACK_RADIUS,
  sampleClosedOvalPoints,
} from './trackGeometry';

export interface TrackBuildResult {
  group: THREE.Group;
  debugCenterline: THREE.LineLoop;
  measuredLapLengthMeters: number;
  setDebugCenterlineVisible: (visible: boolean) => void;
  dispose: () => void;
}

/**
 * Builds a closed annular oval ribbon BufferGeometry between innerR and outerR.
 */
export function buildOvalRibbonGeometry(
  innerR: number,
  outerR: number,
  y: number,
  curveSegments = STADIUM_CONFIG.track.curveSegments,
  uvScale = 0.1
): THREE.BufferGeometry {
  const innerPts = sampleClosedOvalPoints(innerR, curveSegments);
  const outerPts = sampleClosedOvalPoints(outerR, curveSegments);
  const count = innerPts.length;

  const positions: number[] = [];
  const normals: number[] = [];
  const uvs: number[] = [];
  const indices: number[] = [];

  let accumDist = 0;
  for (let i = 0; i < count; i++) {
    const pIn = innerPts[i];
    const pOut = outerPts[i];
    if (i > 0) accumDist += pIn.distanceTo(innerPts[i - 1]);
    positions.push(pIn.x, y, pIn.y, pOut.x, y, pOut.y);
    normals.push(0, 1, 0, 0, 1, 0);
    uvs.push(accumDist * uvScale, 0, accumDist * uvScale, (outerR - innerR) * uvScale);
  }

  for (let i = 0; i < count; i++) {
    const next = (i + 1) % count;
    const a = i * 2;
    const b = i * 2 + 1;
    const c = next * 2;
    const d = next * 2 + 1;
    // Counter-clockwise from above (+Y normal)
    indices.push(a, b, c, b, d, c);
  }

  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geo.setAttribute('normal', new THREE.Float32BufferAttribute(normals, 3));
  geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geo.setIndex(indices);
  return geo;
}

function buildFilledOvalGeometry(
  radius: number,
  y: number,
  curveSegments = STADIUM_CONFIG.track.curveSegments
): THREE.BufferGeometry {
  const pts = sampleClosedOvalPoints(radius, curveSegments);
  const shape = new THREE.Shape();
  // Negate Y before rotateX(-PI/2) so shape maps to (x, z) with +Y upward normal
  shape.moveTo(pts[0].x, -pts[0].y);
  for (let i = 1; i < pts.length; i++) {
    shape.lineTo(pts[i].x, -pts[i].y);
  }
  shape.closePath();

  const geo = new THREE.ShapeGeometry(shape);
  geo.rotateX(-Math.PI / 2);
  geo.translate(0, y, 0);

  const pos = geo.attributes.position;
  const uvs = new Float32Array(pos.count * 2);
  const minX = -(HALF_STRAIGHT + radius);
  const spanX = 2 * (HALF_STRAIGHT + radius);
  const minZ = -radius;
  const spanZ = 2 * radius;
  for (let i = 0; i < pos.count; i++) {
    uvs[i * 2] = (pos.getX(i) - minX) / spanX;
    uvs[i * 2 + 1] = 1 - (pos.getZ(i) - minZ) / spanZ;
  }
  geo.setAttribute('uv', new THREE.BufferAttribute(uvs, 2));
  return geo;
}

/**
 * Builds the complete, closed 400 m synthetic track oval, aprons, curb,
 * striped infield with Pacifica emblem, jump pit, throwing circle,
 * continuous white lane lines, lane numbers 1-8 at start of home straight,
 * and one Finish Line + gantry + photo-finish post.
 */
export function buildClosedTrack(
  maxAnisotropy: number
): TrackBuildResult {
  const T = STADIUM_CONFIG.track;
  const C = STADIUM_CONFIG.colors;

  const group = new THREE.Group();
  group.name = 'Closed400mTrack';

  const trackTex = createTrackSurfaceTexture(maxAnisotropy);
  const turfTex = createInfieldTurfTexture(maxAnisotropy);

  // 1. Royal Blue Synthetic 400m Oval Track (closed loop, 8 lanes)
  const trackMat = new THREE.MeshStandardMaterial({
    map: trackTex,
    roughness: 0.78,
    metalness: 0.02,
  });
  const trackOval = new THREE.Mesh(
    buildOvalRibbonGeometry(KERB_RADIUS, OUTER_TRACK_RADIUS, T.trackSurfaceY, T.curveSegments, 0.14),
    trackMat
  );
  trackOval.receiveShadow = true;
  trackOval.name = 'TrackSurface400m';
  group.add(trackOval);

  // 2. Light-grey inner & outer run-off aprons + white inner curb
  const apronMat = new THREE.MeshStandardMaterial({
    color: C.apronGrey,
    roughness: 0.88,
    metalness: 0.04,
  });
  const innerApron = new THREE.Mesh(
    buildOvalRibbonGeometry(
      KERB_RADIUS - T.innerApronWidth,
      KERB_RADIUS,
      T.infieldTurfY + 0.002,
      T.curveSegments,
      0.05
    ),
    apronMat
  );
  innerApron.receiveShadow = true;
  group.add(innerApron);

  const outerApron = new THREE.Mesh(
    buildOvalRibbonGeometry(
      OUTER_TRACK_RADIUS,
      OUTER_TRACK_RADIUS + T.outerApronWidth,
      T.trackSurfaceY - 0.006,
      T.curveSegments,
      0.05
    ),
    apronMat
  );
  outerApron.receiveShadow = true;
  group.add(outerApron);

  const kerbMat = new THREE.MeshStandardMaterial({
    color: C.white,
    roughness: 0.35,
    metalness: 0.35,
  });
  const innerKerb = new THREE.Mesh(
    buildOvalRibbonGeometry(
      KERB_RADIUS - T.kerbWidth,
      KERB_RADIUS,
      T.trackSurfaceY + T.kerbHeight,
      T.curveSegments,
      0.1
    ),
    kerbMat
  );
  group.add(innerKerb);

  // 3. Striped bright-green turf infield with center Pacifica Regional Olympics emblem
  const turfMat = new THREE.MeshStandardMaterial({
    map: turfTex,
    roughness: 0.92,
    metalness: 0.0,
  });
  const infieldMesh = new THREE.Mesh(
    buildFilledOvalGeometry(KERB_RADIUS - T.innerApronWidth, T.infieldTurfY, T.curveSegments),
    turfMat
  );
  infieldMesh.receiveShadow = true;
  infieldMesh.name = 'InfieldTurf';
  group.add(infieldMesh);

  // Long jump pit + runway & throwing circle on the infield
  const jumpRunway = new THREE.Mesh(new THREE.BoxGeometry(36, 0.014, 1.3), trackMat);
  jumpRunway.position.set(-14, T.infieldTurfY + 0.009, -25.5);
  jumpRunway.receiveShadow = true;
  group.add(jumpRunway);

  const sandPit = new THREE.Mesh(
    new THREE.BoxGeometry(9.5, 0.022, 3.1),
    new THREE.MeshStandardMaterial({ color: C.sandPit, roughness: 0.96 })
  );
  sandPit.position.set(8.8, T.infieldTurfY + 0.011, -25.5);
  sandPit.receiveShadow = true;
  group.add(sandPit);

  const takeoffBoard = new THREE.Mesh(
    new THREE.BoxGeometry(0.26, 0.018, 1.3),
    new THREE.MeshStandardMaterial({ color: '#FFFFFF', roughness: 0.45 })
  );
  takeoffBoard.position.set(2.8, T.infieldTurfY + 0.013, -25.5);
  group.add(takeoffBoard);

  const throwCircle = new THREE.Mesh(
    new THREE.CylinderGeometry(1.25, 1.25, 0.02, 28),
    apronMat
  );
  throwCircle.position.set(24, T.infieldTurfY + 0.011, 2);
  group.add(throwCircle);

  // 4. Continuous 5 cm white lane lines around the whole closed 400m oval
  const whiteLineMat = new THREE.MeshBasicMaterial({
    color: '#FFFFFF',
    polygonOffset: true,
    polygonOffsetFactor: -1,
    polygonOffsetUnits: -1,
  });
  const lineY = T.trackSurfaceY + 0.005;

  for (let b = 0; b <= T.lanes; b++) {
    const r = KERB_RADIUS + b * T.laneWidth;
    const laneLine = new THREE.Mesh(
      buildOvalRibbonGeometry(r - T.lineWidth / 2, r + T.lineWidth / 2, lineY, T.curveSegments, 0.1),
      whiteLineMat
    );
    group.add(laneLine);
  }

  // 5. Lane numbers (1-8) painted at the start of the home straight (-HALF_STRAIGHT, +Z)
  for (let lane = 1; lane <= T.lanes; lane++) {
    const m = getLaneMetrics(lane);
    const numTex = createLaneNumberTexture(lane, maxAnisotropy);
    const numMat = new THREE.MeshBasicMaterial({
      map: numTex,
      transparent: true,
      depthWrite: false,
      polygonOffset: true,
      polygonOffsetFactor: -2,
      polygonOffsetUnits: -2,
    });
    const numPlane = new THREE.Mesh(new THREE.PlaneGeometry(0.84, 0.84), numMat);
    numPlane.rotation.x = -Math.PI / 2;
    numPlane.position.set(-HALF_STRAIGHT + 0.8, lineY + 0.003, m.centerRadius);
    group.add(numPlane);
  }

  // 6. Single Finish Line at end of home straight (+HALF_STRAIGHT, +Z) + Finish Gantry + Photo-Finish Post
  const trackTotalWidth = OUTER_TRACK_RADIUS - KERB_RADIUS;
  const finishLine = new THREE.Mesh(
    new THREE.PlaneGeometry(0.1, trackTotalWidth),
    whiteLineMat
  );
  finishLine.rotation.x = -Math.PI / 2;
  finishLine.position.set(HALF_STRAIGHT, lineY + 0.003, KERB_RADIUS + trackTotalWidth / 2);
  group.add(finishLine);

  const metalMat = new THREE.MeshStandardMaterial({
    color: '#E2E8F0',
    metalness: 0.72,
    roughness: 0.25,
  });
  const darkMetalMat = new THREE.MeshStandardMaterial({
    color: '#0F172A',
    metalness: 0.75,
    roughness: 0.3,
  });

  // Finish Gantry Arch spanning across the home straight at Finish Line
  const gantryGroup = new THREE.Group();
  const zInner = KERB_RADIUS - 0.85;
  const zOuter = OUTER_TRACK_RADIUS + 1.25;
  const zMid = (zInner + zOuter) / 2;
  const span = zOuter - zInner;

  const legIn = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.14, 4.4, 12), metalMat);
  legIn.position.set(HALF_STRAIGHT, 2.2, zInner);
  legIn.castShadow = true;
  gantryGroup.add(legIn);

  const legOut = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.15, 4.4, 12), metalMat);
  legOut.position.set(HALF_STRAIGHT, 2.2, zOuter);
  legOut.castShadow = true;
  gantryGroup.add(legOut);

  const crossBeam = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.42, span + 0.6), darkMetalMat);
  crossBeam.position.set(HALF_STRAIGHT, 4.4, zMid);
  crossBeam.castShadow = true;
  gantryGroup.add(crossBeam);

  // Gold accent strip & FINISH banner on gantry
  const gantryTrim = new THREE.Mesh(
    new THREE.BoxGeometry(0.36, 0.08, span + 0.62),
    new THREE.MeshStandardMaterial({ color: C.goldBright, metalness: 0.6, roughness: 0.3 })
  );
  gantryTrim.position.set(HALF_STRAIGHT, 4.18, zMid);
  gantryGroup.add(gantryTrim);

  // Photo-finish camera post & optical housing
  const photoPost = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.12, 3.7, 12), darkMetalMat);
  photoPost.position.set(HALF_STRAIGHT, 1.85, OUTER_TRACK_RADIUS + 2.3);
  gantryGroup.add(photoPost);

  const photoCam = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.28, 0.36), darkMetalMat);
  photoCam.position.set(HALF_STRAIGHT, 3.75, OUTER_TRACK_RADIUS + 2.3);
  gantryGroup.add(photoCam);

  const photoLens = new THREE.Mesh(
    new THREE.CylinderGeometry(0.08, 0.08, 0.16, 12),
    new THREE.MeshStandardMaterial({ color: '#38BDF8', metalness: 0.9, roughness: 0.1 })
  );
  photoLens.rotation.x = Math.PI / 2;
  photoLens.position.set(HALF_STRAIGHT, 3.75, OUTER_TRACK_RADIUS + 2.08);
  gantryGroup.add(photoLens);

  group.add(gantryGroup);

  // 7. Startup Self-Check: compute Lane 1 measuring-line lap length directly from generated oval points
  const lane1Pts = sampleClosedOvalPoints(T.lane1MeasuringRadius, T.curveSegments);
  const measuredLapLengthMeters = computePolylineLapLength(lane1Pts);
  console.info(
    `[Track Self-Check] Lane 1 closed-loop geometry lap length = ${measuredLapLengthMeters.toFixed(4)} m (target 400.00 m ± 0.01 m)`
  );

  // Debug Toggle LineLoop drawing the exact Lane 1 measuring centerline around the closed oval
  const debugPositions = new Float32Array(lane1Pts.length * 3);
  for (let i = 0; i < lane1Pts.length; i++) {
    debugPositions[i * 3] = lane1Pts[i].x;
    debugPositions[i * 3 + 1] = T.trackSurfaceY + 0.12;
    debugPositions[i * 3 + 2] = lane1Pts[i].y;
  }
  const debugGeo = new THREE.BufferGeometry();
  debugGeo.setAttribute('position', new THREE.BufferAttribute(debugPositions, 3));
  const debugCenterline = new THREE.LineLoop(
    debugGeo,
    new THREE.LineBasicMaterial({ color: '#F5C542' })
  );
  debugCenterline.visible = false;
  debugCenterline.name = 'DebugTrackCenterline';
  group.add(debugCenterline);

  const setDebugCenterlineVisible = (visible: boolean) => {
    debugCenterline.visible = visible;
  };

  const dispose = () => {
    group.traverse((obj) => {
      if (obj instanceof THREE.Mesh || obj instanceof THREE.LineLoop) {
        obj.geometry.dispose();
        if (Array.isArray(obj.material)) obj.material.forEach((m) => m.dispose());
        else obj.material.dispose();
      }
    });
    trackTex.dispose();
    turfTex.dispose();
  };

  return {
    group,
    debugCenterline,
    measuredLapLengthMeters,
    setDebugCenterlineVisible,
    dispose,
  };
}
