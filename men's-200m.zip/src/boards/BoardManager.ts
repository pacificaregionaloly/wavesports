import * as THREE from 'three';
import {
  BoardMessagePayload,
  BoardName,
  BoardSourceKind,
  STADIUM_CONFIG,
} from '../config';
import { getTrackPath } from '../track/trackGeometry';
import {
  BoardScreen,
  BoardSourceOptions,
  PostMessagePayload,
} from './BoardScreen';

/**
 * Manages all stadium LED screens ('eastBoard', 'westBoard', 'ringBoard', 'mainScoreboard'),
 * including a secondary Three.js WebGLRenderTarget scene for live 3D feed projection.
 */
export class BoardManager {
  private screens = new Map<BoardName, BoardScreen>();
  private subScene: THREE.Scene;
  private subCamera: THREE.PerspectiveCamera;
  private renderTarget: THREE.WebGLRenderTarget;
  private subDots: THREE.Mesh[] = [];
  private messageHandler: (ev: MessageEvent) => void;

  constructor(maxAnisotropy: number) {
    // Secondary Three.js Scene & Camera rendered to WebGLRenderTarget for live 3D board feed
    this.renderTarget = new THREE.WebGLRenderTarget(1024, 512, {
      minFilter: THREE.LinearFilter,
      magFilter: THREE.LinearFilter,
    });
    this.renderTarget.texture.colorSpace = THREE.SRGBColorSpace;

    this.subScene = new THREE.Scene();
    this.subScene.background = new THREE.Color('#041436');
    this.subCamera = new THREE.PerspectiveCamera(42, 2, 0.5, 400);

    const subLight = new THREE.DirectionalLight('#FFFFFF', 2.0);
    subLight.position.set(40, 80, 40);
    this.subScene.add(subLight, new THREE.AmbientLight('#93C5FD', 0.9));

    // Mini 3D oval track inside secondary render-target scene
    const ringTrack = new THREE.Mesh(
      new THREE.RingGeometry(35, 47, 64),
      new THREE.MeshStandardMaterial({ color: '#1551A1', side: THREE.DoubleSide })
    );
    ringTrack.rotation.x = -Math.PI / 2;
    this.subScene.add(ringTrack);

    const dotGeo = new THREE.SphereGeometry(1.4, 12, 12);
    for (let i = 0; i < 8; i++) {
      const m = new THREE.Mesh(
        dotGeo,
        new THREE.MeshStandardMaterial({
          color: i === 0 ? '#F5C542' : '#FFFFFF',
          emissive: i === 0 ? '#D4AF37' : '#0EA5E9',
          emissiveIntensity: 0.45,
        })
      );
      this.subScene.add(m);
      this.subDots.push(m);
    }

    // Listen to window.postMessage for external iframe / feed data
    this.messageHandler = (ev: MessageEvent) => {
      const data = ev.data as PostMessagePayload | null;
      if (!data || typeof data !== 'object') return;
      if (data.type !== 'wstv-board') return;
      const target = data.board ?? 'all';
      if (target === 'all') {
        this.screens.forEach((b) => b.handlePostMessage(data));
      } else {
        this.screens.get(target)?.handlePostMessage(data);
      }
    };
    if (typeof window !== 'undefined') {
      window.addEventListener('message', this.messageHandler);
    }
    void maxAnisotropy;
  }

  public register(screen: BoardScreen): void {
    screen.bindSharedRenderTargetTexture(this.renderTarget.texture);
    this.screens.set(screen.name, screen);
  }

  public get(name: BoardName): BoardScreen | undefined {
    return this.screens.get(name);
  }

  public getAll(): BoardScreen[] {
    return Array.from(this.screens.values());
  }

  public setSource(
    name: BoardName,
    kind: BoardSourceKind,
    options?: BoardSourceOptions
  ): void {
    this.screens.get(name)?.setSource(kind, options);
  }

  public writeMessage(
    target: BoardName | 'all',
    message: BoardMessagePayload
  ): void {
    if (target === 'all') {
      this.screens.forEach((screen) => screen.setMessage(message));
    } else {
      this.screens.get(target)?.setMessage(message);
    }
  }

  public sendDemoPostMessage(): void {
    const payload: PostMessagePayload = {
      type: 'wstv-board',
      board: 'all',
      title: 'EXTERNAL POSTMESSAGE FEED · WSTV LIVE',
      clock: new Date().toLocaleTimeString(),
      rows: STADIUM_CONFIG.pacificaNations.slice(0, 6).map((n, idx) => ({
        lane: idx + 1,
        label: `Lane ${idx + 1} · ${n.name}`,
        value: n.code,
      })),
    };
    window.postMessage(payload, '*');
  }

  public update(
    renderer: THREE.WebGLRenderer,
    elapsedSeconds: number,
    nowMs: number,
    isSoftwareGl: boolean
  ): void {
    let anyRenderTargetActive = false;
    this.screens.forEach((screen) => {
      if (screen.getSource() === 'renderTarget') {
        anyRenderTargetActive = true;
      }
      screen.update(elapsedSeconds, nowMs);
    });

    // Only render secondary 3D camera if at least one board uses 'renderTarget'
    if (anyRenderTargetActive && !isSoftwareGl) {
      for (let i = 0; i < this.subDots.length; i++) {
        const path = getTrackPath(i + 1);
        const pt = path.pointAt((elapsedSeconds * (7.8 + (7 - i) * 0.25)) % path.length);
        this.subDots[i].position.set(pt.position.x, 1.5, pt.position.z);
      }
      const camAngle = elapsedSeconds * 0.45;
      this.subCamera.position.set(
        Math.cos(camAngle) * 85,
        42,
        Math.sin(camAngle) * 70
      );
      this.subCamera.lookAt(0, 0, 0);

      const prevTarget = renderer.getRenderTarget();
      renderer.setRenderTarget(this.renderTarget);
      renderer.render(this.subScene, this.subCamera);
      renderer.setRenderTarget(prevTarget);
    }
  }

  public dispose(): void {
    if (typeof window !== 'undefined') {
      window.removeEventListener('message', this.messageHandler);
    }
    this.screens.forEach((s) => s.dispose());
    this.screens.clear();
    this.renderTarget.dispose();
  }
}
