import * as THREE from 'three';
import {
  clearRegisteredStadiumAPI,
  createAndRegisterStadiumAPI,
  StadiumAPI,
  StadiumJSONState,
  StadiumUpdateCallback,
} from '../api/StadiumAPI';
import { BoardManager } from '../boards/BoardManager';
import { CameraController } from '../cameras/CameraController';
import { STADIUM_CONFIG, TimeOfDay } from '../config';
import { CrowdManager } from '../crowd/CrowdManager';
import { PeopleManager } from '../people/PeopleManager';
import { buildClosedTrack, TrackBuildResult } from '../track/TrackBuilder';
import { StadiumEnvironment } from './Environment';
import { buildStadiumStructure, StadiumBuildResult } from './StadiumStructure';

function detectSoftwareWebGL(gl: WebGLRenderingContext | WebGL2RenderingContext): boolean {
  try {
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    if (!ext) return false;
    const rendererStr = String(gl.getParameter(ext.UNMASKED_RENDERER_WEBGL) ?? '');
    return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(rendererStr);
  } catch {
    return false;
  }
}

export interface SceneControllerCallbacks {
  onReady: (api: StadiumAPI, state: StadiumJSONState) => void;
  onStateChange: (state: StadiumJSONState) => void;
  onFpsUpdate: (fps: number) => void;
  onWebGLError: (reason: 'unsupported' | 'context-lost') => void;
}

export class SceneController {
  public readonly api: StadiumAPI;
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private environment: StadiumEnvironment;
  private trackResult: TrackBuildResult;
  private boardManager: BoardManager;
  private stadiumResult: StadiumBuildResult;
  private crowdManager: CrowdManager;
  private peopleManager: PeopleManager;
  private cameraController: CameraController;

  private updateCallbacks = new Set<StadiumUpdateCallback>();
  private state: StadiumJSONState;
  private isSoftwareGl: boolean;
  private disposed = false;
  private rafId = 0;
  private lastTimeMs = performance.now();
  private elapsedSeconds = 0;
  private fpsFrames = 0;
  private fpsLastCheckMs = performance.now();
  private resizeObserver: ResizeObserver;
  private container: HTMLElement;
  private callbacks: SceneControllerCallbacks;

  private onContextLost: (ev: Event) => void;
  private onContextRestored: () => void;

  constructor(container: HTMLElement, callbacks: SceneControllerCallbacks) {
    this.container = container;
    this.callbacks = callbacks;

    // 1. Create canvas & probe WebGL / software fallback before Three.js Renderer
    const testCanvas = document.createElement('canvas');
    const probeGl =
      testCanvas.getContext('webgl2') ||
      testCanvas.getContext('webgl') ||
      testCanvas.getContext('experimental-webgl');
    if (!probeGl) {
      callbacks.onWebGLError('unsupported');
      throw new Error('WebGL not supported');
    }
    this.isSoftwareGl = detectSoftwareWebGL(
      probeGl as WebGLRenderingContext | WebGL2RenderingContext
    );

    const width = Math.max(1, container.clientWidth);
    const height = Math.max(1, container.clientHeight);

    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      powerPreference: 'high-performance',
      alpha: false,
    });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(
      this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio || 1, 2)
    );
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.05;
    this.renderer.shadowMap.enabled = !this.isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    const canvasEl = this.renderer.domElement;
    canvasEl.style.display = 'block';
    canvasEl.style.width = '100%';
    canvasEl.style.height = '100%';
    container.appendChild(canvasEl);

    this.onContextLost = (ev: Event) => {
      ev.preventDefault();
      this.callbacks.onWebGLError('context-lost');
    };
    this.onContextRestored = () => {
      this.lastTimeMs = performance.now();
    };
    canvasEl.addEventListener('webglcontextlost', this.onContextLost);
    canvasEl.addEventListener('webglcontextrestored', this.onContextRestored);

    const maxAnisotropy = Math.min(8, this.renderer.capabilities.getMaxAnisotropy());

    // 2. Scene & Environment
    this.scene = new THREE.Scene();
    this.environment = new StadiumEnvironment(this.scene, this.renderer, this.isSoftwareGl);
    this.scene.add(this.environment.group);

    // 3. Complete Closed 400 m Track + Startup Self-Check
    this.trackResult = buildClosedTrack(maxAnisotropy);
    this.scene.add(this.trackResult.group);

    // 4. LED Boards & Scoreboard Manager
    this.boardManager = new BoardManager(maxAnisotropy);

    // 5. Continuous Two-Tier ~40,000-seat Bowl, Roof, Facade, Plaza, Torch, Ad Boards & Screens
    this.stadiumResult = buildStadiumStructure(this.boardManager, maxAnisotropy);
    this.scene.add(this.stadiumResult.group);

    // 6. Instanced Crowd Spectators + Waving Flags
    this.crowdManager = new CrowdManager(this.stadiumResult.seatSlots, maxAnisotropy);
    this.scene.add(this.crowdManager.group);

    // 7. Officials, Staff, Media, Commentators & 16 Warm-Up Runners (No racing)
    this.peopleManager = new PeopleManager();
    this.scene.add(this.peopleManager.group);

    // 8. Camera & OrbitControls (Starts on Exterior Establishing Shot)
    this.cameraController = new CameraController(
      canvasEl,
      width / height,
      this.isSoftwareGl
    );

    // 9. Plain JSON State Object
    this.state = {
      timeOfDay: 'sunset',
      cameraPreset: 'exterior',
      autoOrbit: false,
      crowdFillPercent: STADIUM_CONFIG.crowd.defaultFillPercent,
      crowdDensity: this.isSoftwareGl
        ? STADIUM_CONFIG.crowd.performanceDensity
        : STADIUM_CONFIG.crowd.defaultDensity,
      cheerWave: false,
      debugCenterline: false,
      performanceMode: this.isSoftwareGl,
      targetFps: 30,
      showLabels: true,
      measuredLapLengthMeters: this.trackResult.measuredLapLengthMeters,
      totalSeatsBuilt: this.stadiumResult.totalSeatsBuilt,
      boards: {
        eastBoard: 'demo',
        westBoard: 'demo',
        ringBoard: 'demo',
        mainScoreboard: 'demo',
      },
    };
    this.crowdManager.setDensity(this.state.crowdDensity);

    // 10. Publish Extension API
    const emitState = () => this.callbacks.onStateChange({ ...this.state, boards: { ...this.state.boards } });

    this.api = createAndRegisterStadiumAPI({
      scene: this.scene,
      cameraController: this.cameraController,
      renderer: this.renderer,
      boardManager: this.boardManager,
      peopleManager: this.peopleManager,
      state: this.state,
      addUpdateCallback: (fn) => {
        this.updateCallbacks.add(fn);
        return () => this.updateCallbacks.delete(fn);
      },
      setTimeOfDay: (tod: TimeOfDay) => {
        this.environment.setTimeOfDay(tod);
        this.state.timeOfDay = tod;
        emitState();
      },
      setCrowdFill: (percent: number) => {
        const clamped = Math.max(0, Math.min(100, Math.round(percent)));
        this.crowdManager.setFillPercent(clamped);
        this.state.crowdFillPercent = clamped;
        emitState();
      },
      setCrowdDensity: (density: number) => {
        const clamped = Math.max(0.1, Math.min(1, Number(density.toFixed(2))));
        this.crowdManager.setDensity(clamped);
        this.state.crowdDensity = clamped;
        emitState();
      },
      setCheerWave: (enabled: boolean) => {
        this.crowdManager.setCheerWave(enabled);
        this.state.cheerWave = enabled;
        emitState();
      },
      setDebugCenterline: (visible: boolean) => {
        this.trackResult.setDebugCenterlineVisible(visible);
        this.state.debugCenterline = visible;
        emitState();
      },
      setPerformanceMode: (enabled: boolean) => {
        this.applyPerformanceMode(enabled);
        emitState();
      },
      setTargetFps: (fps: 30 | 60) => {
        this.state.targetFps = fps;
        emitState();
      },
      onStateChanged: emitState,
    });

    // Resize Observer
    this.resizeObserver = new ResizeObserver(() => {
      const w = Math.max(1, this.container.clientWidth);
      const h = Math.max(1, this.container.clientHeight);
      this.renderer.setSize(w, h);
      this.cameraController.resize(w, h);
    });
    this.resizeObserver.observe(container);

    // Start Render Loop
    callbacks.onReady(this.api, { ...this.state, boards: { ...this.state.boards } });
    this.scheduleNextFrame();
  }

  private applyPerformanceMode(enabled: boolean): void {
    this.state.performanceMode = enabled;
    if (enabled) {
      this.renderer.setPixelRatio(1);
      this.renderer.shadowMap.enabled = false;
      this.environment.setShadowsEnabled(false);
      this.state.crowdDensity = STADIUM_CONFIG.crowd.performanceDensity;
      this.crowdManager.setDensity(this.state.crowdDensity);
    } else {
      this.renderer.setPixelRatio(
        this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio || 1, 2)
      );
      this.renderer.shadowMap.enabled = !this.isSoftwareGl;
      this.environment.setShadowsEnabled(!this.isSoftwareGl);
      this.state.crowdDensity = STADIUM_CONFIG.crowd.defaultDensity;
      this.crowdManager.setDensity(this.state.crowdDensity);
    }
  }

  private scheduleNextFrame(): void {
    if (this.disposed) return;
    this.rafId = requestAnimationFrame(this.tick);
  }

  private afterDraw(done: () => void): void {
    if (!this.isSoftwareGl) {
      done();
      return;
    }
    const gl = this.renderer.getContext() as WebGL2RenderingContext;
    if (!gl || typeof gl.fenceSync !== 'function') {
      setTimeout(done, 0);
      return;
    }
    const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
    if (!sync) {
      setTimeout(done, 0);
      return;
    }
    gl.flush();
    const t0 = performance.now();
    const check = () => {
      if (this.disposed) {
        gl.deleteSync(sync);
        return;
      }
      const status = gl.clientWaitSync(sync, 0, 0);
      if (status !== gl.TIMEOUT_EXPIRED || performance.now() - t0 > 80) {
        gl.deleteSync(sync);
        done();
      } else {
        setTimeout(check, 2);
      }
    };
    setTimeout(check, 1);
  }

  private tick = (nowMs: number): void => {
    if (this.disposed) return;

    const minIntervalMs = 1000 / this.state.targetFps;
    const elapsedSinceRenderMs = nowMs - this.lastTimeMs;
    // Allow 1.5 ms vsync jitter tolerance so 60 Hz displays lock cleanly to 30 FPS
    if (elapsedSinceRenderMs < minIntervalMs - 1.5) {
      this.scheduleNextFrame();
      return;
    }

    const rawDt = elapsedSinceRenderMs / 1000;
    this.lastTimeMs = nowMs;
    const dt = Math.min(0.1, Math.max(0.001, rawDt));
    this.elapsedSeconds += dt;

    // Update subsystems
    this.environment.update(this.elapsedSeconds);
    this.stadiumResult.update(this.elapsedSeconds);
    this.crowdManager.update(this.elapsedSeconds, dt);
    this.peopleManager.update(this.elapsedSeconds, dt);
    this.boardManager.update(
      this.renderer,
      this.elapsedSeconds,
      nowMs,
      this.isSoftwareGl
    );
    this.cameraController.update(dt);

    // Run registered Extension API callbacks
    this.updateCallbacks.forEach((fn) => {
      try {
        fn(this.elapsedSeconds, dt);
      } catch (err) {
        console.error('[WSTV Extension Update Error]', err);
      }
    });

    // Render frame
    this.renderer.render(this.scene, this.cameraController.camera);

    // Measure FPS once per 500ms
    this.fpsFrames++;
    if (nowMs - this.fpsLastCheckMs >= 500) {
      const fps = Math.round((this.fpsFrames * 1000) / (nowMs - this.fpsLastCheckMs));
      this.callbacks.onFpsUpdate(fps);
      this.fpsFrames = 0;
      this.fpsLastCheckMs = nowMs;
    }

    this.afterDraw(() => this.scheduleNextFrame());
  };

  public dispose(): void {
    this.disposed = true;
    cancelAnimationFrame(this.rafId);
    this.resizeObserver.disconnect();
    clearRegisteredStadiumAPI();

    const canvasEl = this.renderer.domElement;
    canvasEl.removeEventListener('webglcontextlost', this.onContextLost);
    canvasEl.removeEventListener('webglcontextrestored', this.onContextRestored);

    this.cameraController.dispose();
    this.peopleManager.dispose();
    this.crowdManager.dispose();
    this.stadiumResult.dispose();
    this.boardManager.dispose();
    this.trackResult.dispose();
    this.environment.dispose();

    this.renderer.dispose();
    if (canvasEl.parentNode) {
      canvasEl.parentNode.removeChild(canvasEl);
    }
  }
}
