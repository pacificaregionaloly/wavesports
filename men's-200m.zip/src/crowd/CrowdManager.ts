import * as THREE from 'three';
import { createNewPleadlandFlagTexture } from '../branding/textures';
import { STADIUM_CONFIG } from '../config';

export interface SeatSlot {
  position: THREE.Vector3;
  rotY: number;
}

/**
 * Manages instanced low-poly spectators and shader-animated waving flags across the entire 2-tier bowl.
 * Supports live fill-percentage, crowd density slider, and idle vs cheer/wave animation toggle.
 */
export class CrowdManager {
  public readonly group = new THREE.Group();
  private crowdMesh: THREE.InstancedMesh;
  private flagsMesh: THREE.InstancedMesh;
  private maxSpectators: number;
  private maxFlags: number;
  private fillPercent = STADIUM_CONFIG.crowd.defaultFillPercent;
  private density = STADIUM_CONFIG.crowd.defaultDensity;
  private cheerWave = false;

  private crowdUniforms = {
    uTime: { value: 0 },
    uCheer: { value: 0 },
  };
  private flagUniforms = {
    uTime: { value: 0 },
    uCheer: { value: 0 },
  };

  constructor(seatSlots: SeatSlot[], maxAnisotropy: number) {
    this.group.name = 'CrowdGroup';
    const C = STADIUM_CONFIG.colors;

    // Deterministic shuffle so reducing density or fill% thins evenly across the whole bowl
    const shuffled = [...seatSlots];
    let seed = 424242;
    const rand = () => {
      seed = (seed * 1664525 + 1013904223) >>> 0;
      return seed / 4294967296;
    };
    for (let i = shuffled.length - 1; i > 0; i--) {
      const j = Math.floor(rand() * (i + 1));
      const tmp = shuffled[i];
      shuffled[i] = shuffled[j];
      shuffled[j] = tmp;
    }

    this.maxSpectators = Math.min(shuffled.length, STADIUM_CONFIG.crowd.maxSpectators);
    this.maxFlags = Math.min(this.maxSpectators, STADIUM_CONFIG.crowd.handFlagCount);

    // Stylized torso + head silhouette merged in a lightweight cylinder-cone geometry
    const spectatorGeo = new THREE.CylinderGeometry(0.15, 0.21, 0.82, 6);
    spectatorGeo.translate(0, 0.44, 0);

    const crowdMat = new THREE.MeshStandardMaterial({ roughness: 0.85 });
    crowdMat.onBeforeCompile = (shader) => {
      shader.uniforms.uTime = this.crowdUniforms.uTime;
      shader.uniforms.uCheer = this.crowdUniforms.uCheer;
      shader.vertexShader =
        `uniform float uTime;\nuniform float uCheer;\n` +
        shader.vertexShader.replace(
          '#include <begin_vertex>',
          `#include <begin_vertex>
           vec4 wPos = instanceMatrix * vec4(0.0, 0.0, 0.0, 1.0);
           float phase = wPos.x * 0.63 + wPos.z * 0.47;
           float idleSway = sin(uTime * 1.6 + phase) * 0.028;
           float angle = atan(wPos.z, wPos.x);
           float stadiumWave = max(0.0, sin(angle * 2.0 - uTime * 2.6)) * 0.28;
           float cheerJump = abs(sin(uTime * 6.5 + phase)) * 0.22;
           transformed.y += idleSway + uCheer * (stadiumWave + cheerJump);
           transformed.x += idleSway * 0.4;
          `
        );
    };

    this.crowdMesh = new THREE.InstancedMesh(spectatorGeo, crowdMat, this.maxSpectators);
    this.crowdMesh.name = 'CrowdSpectators';

    const dummy = new THREE.Object3D();
    const palette = [
      new THREE.Color(C.newPleadlandBlue),
      new THREE.Color('#1D5FD6'),
      new THREE.Color('#F8FAFC'),
      new THREE.Color(C.goldBright),
      new THREE.Color('#0EA5E9'),
      new THREE.Color('#DC2626'),
      new THREE.Color('#16A34A'),
    ];

    for (let i = 0; i < this.maxSpectators; i++) {
      const slot = shuffled[i];
      dummy.position.set(slot.position.x, slot.position.y + 0.14, slot.position.z);
      dummy.rotation.set(0, slot.rotY + (rand() - 0.5) * 0.3, 0);
      // Varied heights and widths
      dummy.scale.set(0.86 + rand() * 0.28, 0.85 + rand() * 0.34, 0.86 + rand() * 0.28);
      dummy.updateMatrix();
      this.crowdMesh.setMatrixAt(i, dummy.matrix);

      // Predominantly blue, white, gold, with a few Pacifica accent colors
      const r = rand();
      const col =
        r < 0.44
          ? palette[0]
          : r < 0.62
          ? palette[1]
          : r < 0.84
          ? palette[2]
          : r < 0.93
          ? palette[3]
          : palette[4 + Math.floor(rand() * 3)];
      this.crowdMesh.setColorAt(i, col);
    }
    this.crowdMesh.instanceMatrix.needsUpdate = true;
    if (this.crowdMesh.instanceColor) this.crowdMesh.instanceColor.needsUpdate = true;
    this.crowdMesh.computeBoundingSphere();
    this.group.add(this.crowdMesh);

    // Animated Waving Hand Flags (vertex shader cloth flutter)
    const flagGeo = new THREE.PlaneGeometry(0.68, 0.44, 6, 2);
    flagGeo.translate(0.34, 0.22, 0); // pivot from pole edge
    const flagTex = createNewPleadlandFlagTexture(maxAnisotropy);
    const flagMat = new THREE.MeshStandardMaterial({
      map: flagTex,
      roughness: 0.7,
      side: THREE.DoubleSide,
    });
    flagMat.onBeforeCompile = (shader) => {
      shader.uniforms.uTime = this.flagUniforms.uTime;
      shader.uniforms.uCheer = this.flagUniforms.uCheer;
      shader.vertexShader =
        `uniform float uTime;\nuniform float uCheer;\n` +
        shader.vertexShader.replace(
          '#include <begin_vertex>',
          `#include <begin_vertex>
           vec4 wPos = instanceMatrix * vec4(0.0, 0.0, 0.0, 1.0);
           float p = wPos.x * 0.3 + wPos.z * 0.3;
           float amp = 0.08 + uCheer * 0.14;
           transformed.z += sin(position.x * 8.0 - uTime * (5.0 + uCheer * 4.0) + p) * amp * position.x;
           transformed.y += sin(uTime * 3.5 + p) * (0.06 + uCheer * 0.18);
          `
        );
    };

    this.flagsMesh = new THREE.InstancedMesh(flagGeo, flagMat, this.maxFlags);
    this.flagsMesh.name = 'CrowdWavingFlags';
    for (let i = 0; i < this.maxFlags; i++) {
      const slot = shuffled[i * Math.max(1, Math.floor(this.maxSpectators / this.maxFlags))];
      dummy.position.set(slot.position.x, slot.position.y + 0.92, slot.position.z);
      dummy.rotation.set(0, slot.rotY + (rand() - 0.5) * 0.6, 0.15);
      dummy.scale.setScalar(1);
      dummy.updateMatrix();
      this.flagsMesh.setMatrixAt(i, dummy.matrix);
    }
    this.flagsMesh.instanceMatrix.needsUpdate = true;
    this.flagsMesh.computeBoundingSphere();
    this.group.add(this.flagsMesh);

    this.applyVisibilityCounts();
  }

  public setFillPercent(percent: number): void {
    this.fillPercent = Math.max(0, Math.min(100, percent));
    this.applyVisibilityCounts();
  }

  public setDensity(density: number): void {
    this.density = Math.max(0.05, Math.min(1, density));
    this.applyVisibilityCounts();
  }

  public setCheerWave(enabled: boolean): void {
    this.cheerWave = enabled;
  }

  private applyVisibilityCounts(): void {
    const ratio = (this.fillPercent / 100) * this.density;
    this.crowdMesh.count = Math.floor(this.maxSpectators * ratio);
    this.flagsMesh.count = Math.floor(this.maxFlags * ratio);
  }

  public update(elapsedSeconds: number, dt: number): void {
    this.crowdUniforms.uTime.value = elapsedSeconds;
    this.flagUniforms.uTime.value = elapsedSeconds;
    const targetCheer = this.cheerWave ? 1.0 : 0.0;
    this.crowdUniforms.uCheer.value +=
      (targetCheer - this.crowdUniforms.uCheer.value) * Math.min(1, dt * 4);
    this.flagUniforms.uCheer.value = this.crowdUniforms.uCheer.value;
  }

  public dispose(): void {
    this.crowdMesh.geometry.dispose();
    (this.crowdMesh.material as THREE.Material).dispose();
    this.flagsMesh.geometry.dispose();
    const fMat = this.flagsMesh.material as THREE.MeshStandardMaterial;
    fMat.map?.dispose();
    fMat.dispose();
  }
}
