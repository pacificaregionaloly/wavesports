import React from 'react';
import { STADIUM_CONFIG } from '../config';

interface WebGLFallbackProps {
  reason: 'unsupported' | 'context-lost';
  onRetry?: () => void;
}

export const WebGLFallback: React.FC<WebGLFallbackProps> = ({ reason, onRetry }) => {
  return (
    <div
      role="alert"
      className="fixed inset-0 z-50 flex items-center justify-center bg-[#040d21] p-6 text-slate-100"
    >
      <div className="max-w-lg w-full rounded-xl border border-[#d4af37]/40 bg-[#071738] p-8 shadow-2xl">
        <div className="text-xs font-semibold tracking-wider text-[#f5c542] uppercase">
          {STADIUM_CONFIG.venue.broadcasterName} · {STADIUM_CONFIG.venue.gamesTitle}
        </div>
        <h1 className="mt-2 font-display text-3xl font-bold tracking-tight text-white">
          {reason === 'unsupported'
            ? '3D Graphics (WebGL) Unavailable'
            : '3D Graphics Context Interrupted'}
        </h1>
        <p className="mt-3 text-sm leading-relaxed text-slate-300">
          {reason === 'unsupported'
            ? 'Your browser or device currently has WebGL disabled or unsupported. Klemonserrat Stadium 3D requires WebGL to render the interactive venue environment.'
            : 'The browser temporarily suspended the WebGL graphics context due to hardware or power management.'}
        </p>
        <div className="mt-5 rounded-lg border border-white/10 bg-[#041029] p-4 text-xs text-slate-300 space-y-1.5">
          <div>
            Venue: {STADIUM_CONFIG.venue.name}, {STADIUM_CONFIG.venue.city} ({STADIUM_CONFIG.venue.country})
          </div>
          <div>Track: Closed 400.00 m Regulation 8-Lane Oval</div>
          <div>Tip: Enable hardware acceleration in browser settings and reload.</div>
        </div>
        {onRetry && (
          <button
            type="button"
            onClick={onRetry}
            className="mt-6 rounded-lg bg-[#0033a0] px-5 py-2.5 text-sm font-semibold text-white hover:bg-[#144d9e] focus-visible:outline-2 focus-visible:outline-[#f5c542]"
          >
            Reload 3D Stadium
          </button>
        )}
      </div>
    </div>
  );
};
