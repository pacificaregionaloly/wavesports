/**
 * Central Configuration for Klemonserrat Stadium 3D Environment.
 * Every track dimension, architectural measurement, color, count, branding slot,
 * and camera preset is defined here.
 */

export type TimeOfDay = 'day' | 'sunset' | 'night';

export type CameraPresetId =
  | 'exterior'
  | 'aerial'
  | 'overhead'
  | 'finishLine'
  | 'homeStraight'
  | 'backStraight'
  | 'standsView'
  | 'infield';

export type BoardSourceKind =
  | 'demo'
  | 'canvas2d'
  | 'video'
  | 'renderTarget'
  | 'postMessage'
  | 'message';

export type BoardMessageTheme = 'royal' | 'gold' | 'alert';

export interface BoardMessagePayload {
  title: string;
  body?: string;
  ticker?: string;
  theme?: BoardMessageTheme;
}

export type BoardName = 'eastBoard' | 'westBoard' | 'ringBoard' | 'mainScoreboard';

export const STADIUM_CONFIG = {
  venue: {
    name: 'Klemonserrat Stadium',
    city: 'Plead City',
    country: 'New Pleadland',
    gamesTitle: '1st Pacifica Regional Olympics 2026',
    broadcasterName: 'Wavesports Television',
    broadcasterShort: 'WSTV',
  },

  /**
   * World Athletics Regulation Closed 400m Oval Geometry (meters)
   * Two straights of 84.39 m + two semicircular bends with Lane 1 measuring line at 36.80 m.
   * Analytical lap length = 2 * 84.39 + 2 * PI * 36.80 = 400.0012 m.
   */
  track: {
    lanes: 8,
    laneWidth: 1.22,
    lineWidth: 0.05,
    straightLength: 84.39,
    lane1MeasuringRadius: 36.80,
    lane1MeasureOffset: 0.30, // Inner kerb outer face is at 36.50 m
    outerLaneMeasureOffset: 0.20,
    kerbWidth: 0.09,
    kerbHeight: 0.05,
    innerApronWidth: 2.4,
    outerApronWidth: 3.4,
    trackSurfaceY: 0.04,
    infieldTurfY: 0.03,
    curveSegments: 128, // high tessellation per semicircular bend for exact 400.00 m self-check
  },

  /**
   * Architectural & Bowl Dimensions
   */
  stadium: {
    bowlInnerOffset: 4.8,
    tier1Rows: 22,
    tier2Rows: 24,
    seatWidth: 0.50,
    rowDepth: 0.84,
    rowRise: 0.42,
    concourseGap: 3.2,
    aisleEverySeats: 26,
    vomitoryEverySeats: 78,
    seatCountTarget: 40000,
    facadeHeightOffset: 2.0,
    mastHeight: 49.0,
    mastCountPerSide: 7,
    floodlightHeight: 56.0,
    palmTreeCount: 44,
    plazaFlagCount: 8,
  },

  /**
   * Crowd Settings
   */
  crowd: {
    maxSpectators: 18000,
    defaultFillPercent: 78,
    defaultDensity: 1.0, // 0.1 .. 1.0 multiplier
    performanceDensity: 0.32,
    handFlagCount: 640,
  },

  /**
   * Colors & Palette
   */
  colors: {
    newPleadlandBlue: '#0033A0',
    royalBlueDark: '#041436',
    trackRoyalBlue: '#1551A1',
    white: '#F8FAFC',
    gold: '#D4AF37',
    goldBright: '#F5C542',
    black: '#0A0D14',
    turfLight: '#3EA33E',
    turfDark: '#2F8731',
    apronGrey: '#94A3B8',
    sandPit: '#E5CB93',
    concrete: '#CBD5E1',
    steel: '#E2E8F0',
    // Sky / Atmosphere presets
    skyDayTop: '#1D68C4',
    skyDayHorizon: '#CBE4F9',
    skySunsetTop: '#1E2A5E',
    skySunsetHorizon: '#F59E6C',
    skyNightTop: '#030816',
    skyNightHorizon: '#0F2247',
    oceanDay: '#0B5A8C',
    oceanSunset: '#1C4B75',
    oceanNight: '#051529',
  },

  /**
   * Replaceable Branding & Athlete Model Slots
   * Provide a URL/path to override any procedural Canvas/SVG logo or athlete model.
   * Leave as `null` to use the built-in procedural generators with zero external requests.
   */
  brandingSlots: {
    newPleadlandFlagUrl: null as string | null,
    pacificaEmblemUrl: null as string | null,
    wstvLogoUrl: null as string | null,
    customAthleteGlbUrl: null as string | null,
  },

  /**
   * Pacifica Nations Palette (for crowd hand-flags & athlete kits)
   */
  pacificaNations: [
    { code: 'NPL', name: 'New Pleadland', primary: '#0033A0', secondary: '#F8FAFC' },
    { code: 'FIJ', name: 'Fiji', primary: '#002868', secondary: '#68BFE5' },
    { code: 'SAM', name: 'Samoa', primary: '#002B7F', secondary: '#CE1126' },
    { code: 'TON', name: 'Tonga', primary: '#C10000', secondary: '#F8FAFC' },
    { code: 'PNG', name: 'Papua New Guinea', primary: '#CE1126', secondary: '#FCD116' },
    { code: 'AUS', name: 'Australia', primary: '#00843D', secondary: '#FFCD00' },
    { code: 'NZL', name: 'New Zealand', primary: '#111827', secondary: '#F8FAFC' },
    { code: 'SOL', name: 'Solomon Islands', primary: '#0051BA', secondary: '#215B33' },
  ],

  /**
   * Camera Presets (Starts with Exterior Establishing Shot)
   */
  cameras: {
    exterior: { label: 'Exterior', pos: [-126, 46, 124] as [number, number, number], target: [0, 8, 0] as [number, number, number], fov: 44 },
    aerial: { label: 'Aerial', pos: [-94, 68, 92] as [number, number, number], target: [0, 4, 0] as [number, number, number], fov: 46 },
    overhead: { label: 'Overhead', pos: [0, 152, 0.5] as [number, number, number], target: [0, 0, 0] as [number, number, number], fov: 48 },
    finishLine: { label: 'Finish Line', pos: [62, 6.5, 48] as [number, number, number], target: [42.195, 1.5, 41.3] as [number, number, number], fov: 38 },
    homeStraight: { label: 'Home Straight', pos: [-56, 7.5, 43] as [number, number, number], target: [26, 1.8, 41] as [number, number, number], fov: 40 },
    backStraight: { label: 'Back Straight', pos: [54, 7.5, -43] as [number, number, number], target: [-26, 1.8, -41] as [number, number, number], fov: 40 },
    standsView: { label: 'Stands View', pos: [-26, 22, 74] as [number, number, number], target: [10, 2, 0] as [number, number, number], fov: 46 },
    infield: { label: 'Infield', pos: [-12, 3.2, 8] as [number, number, number], target: [24, 6, 36] as [number, number, number], fov: 50 },
  },
};
